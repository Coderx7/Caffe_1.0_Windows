#In the name of Allah
import torch.utils.data as data
from PIL import Image
from skimage.io import imsave
import scipy.io as sio
from pathlib import Path
import numpy as np 
import os



# Download these files first and copy them into a folder, then 
# specify that folder as your source directory 
split_list = {
    'train': ["http://ufldl.stanford.edu/housenumbers/train_32x32.mat",
              "train_32x32.mat", "e26dedcc434d2e4c54c9b2d4a06d8373"],
    'test': ["http://ufldl.stanford.edu/housenumbers/test_32x32.mat",
             "test_32x32.mat", "eb5a983be6a315427106f1b164d9cef3"],
    'extra': ["http://ufldl.stanford.edu/housenumbers/extra_32x32.mat",
              "extra_32x32.mat", "a93ce644f1a588dc4d68dda5feec44a7"]
     }

source_dir = '/media/hossein/tmpstore/SimpNet_PyTorch/data/cifar.python/svhn'
save_directory = '/media/hossein/SSD/svhn'

for matfile in os.listdir(source_dir):
  # reading(loading) mat file as array
    loaded_mat = sio.loadmat(os.path.join(source_dir, matfile))
    # The matrix shape is (32,32,3,# of samples)
    for idx in range(loaded_mat['X'].shape[3]):   
      img = Image.fromarray(loaded_mat['X'][:,:,:,idx]).convert('RGB')

      # loading from the .mat file gives an np array of type np.uint8
	  # converting to np.int64, so that we have a LongTensor after
	  # the conversion from the numpy array
	  # the squeeze is needed to obtain a 1D tensor
      labels = loaded_mat['y'].astype(np.int64).squeeze()
      # the svhn dataset assigns the class label "10" to the digit 0
	  # this makes it inconsistent with several loss functions
	  # which expect the class labels to be in the range [0, C-1]
      np.place(labels, labels == 10, 0)
      
      prefix = 'test' if 'test' in Path(matfile).stem else 'train-extra'
      image_name = '{0}/{1}/{2}_{3}.jpg'.format(prefix, labels[idx], Path(matfile).stem, idx)
      
      full_path = os.path.join(save_directory, image_name)
      print('{0} '.format(image_name))

      Path(os.path.dirname(full_path)).mkdir(parents=True, exist_ok=True) 

      img.save(full_path)
      #imsave(full_path, img)
   #  self.data = np.transpose(self.data, (3, 2, 0, 1))