'''
In the name of GOD
SimpNet in Pytorch.
# Strategy 2
# 2L-K3-S2 - repeat 3 times 
# (112 56 56 56 56 28 28 28 28 28 14 14 14 )

'''
import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F

class simpnet_imgnet_1m_nodrp_s2(nn.Module):
    def __init__(self, classes=1000, simpnet_name='simpnet_imgnet_1m_nodrp_s2'):
        super(simpnet_imgnet_1m_nodrp_s2, self).__init__()
        #print(simpnet_name)
        self.features = self._make_layers() #self._make_layers(cfg[simpnet_name])
        self.classifier = nn.Linear(150, classes)

    def load_my_state_dict(self, state_dict):

        own_state = self.state_dict()

        # print(own_state.keys())
        # for name, val in own_state:
        # print(name)
        for name, param in state_dict.items():
            name = name.replace('module.', '')
            if name not in own_state:
                # print(name)
                continue
            if isinstance(param, Parameter):
                # backwards compatibility for serialized parameters
                param = param.data
            print("STATE_DICT: {}".format(name))
            try:
                own_state[name].copy_(param)
            except:
                print('While copying the parameter named {}, whose dimensions in the model are'
                      ' {} and whose dimensions in the checkpoint are {}, ... Using Initial Params'.format(
                    name, own_state[name].size(), param.size()))

    def forward(self, x):
        #print(x.size())
        out = self.features(x)

        #Global Max Pooling
        out = F.max_pool2d(out, kernel_size=out.size()[2:]) 
        #out = F.dropout2d(out, 0.05, training=True)

        out = out.view(out.size(0), -1)
        out = self.classifier(out)
        return out

    def _make_layers(self):

        model = nn.Sequential(
                             nn.Conv2d(3, 60, kernel_size=[3, 3], stride=(2, 2), padding=(1, 1)),
                             nn.BatchNorm2d(60, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.05),

                             nn.Conv2d(60, 80, kernel_size=[3, 3], stride=(2, 2), padding=(1, 1)),
                             nn.BatchNorm2d(80, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.05),

                             nn.Conv2d(80, 80, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(80, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.05),

                             nn.Conv2d(80, 80, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(80, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.05),

                             nn.Conv2d(80, 85, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(85, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),


                             nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2), dilation=(1, 1), ceil_mode=False),
                             #nn.Dropout2d(p=0.05),


                             nn.Conv2d(85, 85, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(85, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.05),

                             nn.Conv2d(85, 90, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(90, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.05),

                             nn.Conv2d(90, 90, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(90, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.05),

                             nn.Conv2d(90, 90, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(90, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.05),

                             nn.Conv2d(90, 110, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(110, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),


                             nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2), dilation=(1, 1), ceil_mode=False),
                             #nn.Dropout2d(p=0.05),


                             nn.Conv2d(110, 110, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(110, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.05),

                             nn.Conv2d(110, 127, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(127, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.05),

                             nn.Conv2d(127, 150, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(150, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                            )

        for m in self.modules():
          if isinstance(m, nn.Conv2d):
            nn.init.xavier_uniform_(m.weight.data, gain=nn.init.calculate_gain('relu'))

        return model