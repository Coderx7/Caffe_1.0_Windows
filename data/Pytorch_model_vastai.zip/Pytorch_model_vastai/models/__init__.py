"""The models subpackage contains definitions for the following model
architectures:
-  `ResNeXt` for CIFAR10 CIFAR100
You can construct a model with random weights by calling its constructor:
.. code:: python
    import models
    resnext29_16_64 = models.ResNeXt29_16_64(num_classes)
    resnext29_8_64 = models.ResNeXt29_8_64(num_classes)
    resnet20 = models.ResNet20(num_classes)
    resnet32 = models.ResNet32(num_classes)


.. ResNext: https://arxiv.org/abs/1611.05431
"""

from .mobilenet import mobilenet
# from .mobilenet_32 import mobilenet_32
from .mobilenetv2_2 import mobilenet2
# from .mobilenetv2_2_32 import mobilenet2_32
from .shufflenet import ShuffleNetV2

from .resnext import resnext29_8_64, resnext29_16_64
from .resnet import resnet20, resnet32, resnet44, resnet56, resnet110
from .preresnet import preresnet20, preresnet32, preresnet44, preresnet56, preresnet110
from .caffe_cifar import caffe_cifar
from .densenet import densenet100_12
from .resnet_mod import resnet_mod20, resnet_mod32, resnet_mod44, resnet_mod56, resnet_mod110
from .squeezenet import squeezenet1_0, squeezenet1_1

from .simpnet import simpnet
# from .simpnet_imgnet_drpall_32 import simpnet_imgnet_drpall_32

from .simpnet_imgnet_drpall_5m_s_0 import simpnet_imgnet_5m_drpall_s_0 
from .simpnet_imgnet_drpall_5m_s_3 import simpnet_imgnet_5m_drpall_s_3 

from .simpnet_imgnet_drpall_5m_s_4 import simpnet_imgnet_5m_drpall_s_4 
from .simpnet_imgnet_drpall_5m_s_4_1 import simpnet_imgnet_5m_drpall_s_4_1 

from .simpnet_imgnet_drpall_5m_s_5 import simpnet_imgnet_5m_drpall_s_5 
from .simpnet_imgnet_drpall_5m_s_6 import simpnet_imgnet_5m_drpall_s_6 
from .simpnet_imgnet_drpall_5m_s_7 import simpnet_imgnet_5m_drpall_s_7 


from .simpnet_imgnet_drpall_5m_s_6 import simpnet_imgnet_5m_drpall_s_6


from .simpnet_imgnet_drp_1m_s4 import simpnet_imgnet_1m_drp_s4
from .simpnet_imgnet_drp_1m_s6 import simpnet_imgnet_1m_drp_s6


#enhanced version 
from .simpnet_imgnet_drpall_5m_15_s1 import simpnet_imgnet_5m_drpall_15_s1
from .simpnet_enhanced import simpnet_enhanced

from .simpnet300k import simpnet300k 
from .simpnet600k import simpnet600k 
from .simpnet1m import simpnet1m 
from .simpnet8m import simpnet8m 
from .simpnet15m import simpnet15m 
from .simpnet15mbc import simpnet15mbc 
from .simpnet25m import simpnet25m 
from .simpnet20m2 import simpnet20m2 
from .simplenet import simplenet


from .simpnet_imgnet_nodrp_1m_s1 import simpnet_imgnet_1m_nodrp_s1 
from .simpnet_imgnet_nodrp_1m_s2 import simpnet_imgnet_1m_nodrp_s2 

from .simpnet_imgnet_nodrp_300k_s1 import simpnet_imgnet_300k_nodrp_s1 
from .simpnet_imgnet_nodrp_300k_s2 import simpnet_imgnet_300k_nodrp_s2  

from .simpnet_imgnet_nodrp_600k_s1 import simpnet_imgnet_600k_nodrp_s1 
from .simpnet_imgnet_nodrp_600k_s2 import simpnet_imgnet_600k_nodrp_s2 


# strategy 1
from .simpnet_imgnet_drpall_5m_s1 import simpnet_imgnet_5m_drpall_s1
from .simpnet_imgnet_drpall_5m_s1_dw import simpnet_imgnet_5m_drpall_s1_dw
from .simpnet_imgnet_drpall_8m_s1 import simpnet_imgnet_8m_drpall_s1
from .simpnet_imgnet_nodrp_5m_s1 import simpnet_imgnet_5m_nodrp_s1
from .simpnet_imgnet_nodrp_maxdrp_5m_s1 import simpnet_imgnet_5m_nodrp_safc_s1
from .simpnet_imgnet_nodrp_8m_s1 import simpnet_imgnet_8m_nodrp_s1
from .simpnet_imgnet_nodrp_maxdrp_8m_s1 import simpnet_imgnet_8m_nodrp_safc_s1


# strategt 2 
from .simpnet_imgnet_drpall_5m_s2 import simpnet_imgnet_5m_drpall_s2
from .simpnet_imgnet_drpall_8m_s2 import simpnet_imgnet_8m_drpall_s2


from .simpnet_imgnet_drpall_8m_s4 import simpnet_imgnet_8m_drpall_s4
from .simpnet_imgnet_drpall_8m_s6 import simpnet_imgnet_8m_drpall_s6


from .simpnet_imgnet_nodrp_5m_s2 import simpnet_imgnet_5m_nodrp_s2
#enhanced
from .simpnet_v2_imgnet_nodrp_5m_s2 import simpnet_v2_imgnet_5m_nodrp_s2


from .simpnet_imgnet_nodrp_maxdrp_5m_s2 import simpnet_imgnet_5m_nodrp_safc_s2

from .simpnet_imgnet_nodrp_8m_s2 import simpnet_imgnet_8m_nodrp_s2
from .simpnet_imgnet_nodrp_maxdrp_8m_s2 import simpnet_imgnet_8m_nodrp_safc_s2


# strategy 3 
from .simpnet_imgnet_drpall_5m_s3 import simpnet_imgnet_5m_drpall_s3
from .simpnet_imgnet_drpall_8m_s3 import simpnet_imgnet_8m_drpall_s3
from .simpnet_imgnet_nodrp_5m_s3 import simpnet_imgnet_5m_nodrp_s3
from .simpnet_imgnet_nodrp_maxdrp_5m_s3 import simpnet_imgnet_5m_nodrp_safc_s3
from .simpnet_imgnet_nodrp_maxdrp_8m_s3 import simpnet_imgnet_8m_nodrp_safc_s3


# SimpleNetV1
from .simplenet_v1_imgnet import simplenet_imagenet
from .simplenet_v1_imgnet_224 import simplenet_imagenet_224
from .simplenet_v1_p3_imgnet import simplenetv1_imagenet_3p
from .simplenet_v1_imgnet_p3_v2 import simplenetv1_imagenet_3p_v2
from .simplenet_v1_safc_imgnet import simplenet_imagenet_safc



# 300K/600K/1M tests for imagenet
from .simpnet_imgnet_nodrp_300k_s1 import simpnet_imgnet_300k_nodrp_s1
from .simpnet_imgnet_nodrp_300k_s2 import simpnet_imgnet_300k_nodrp_s2
from .simpnet_imgnet_nodrp_300k_s3 import simpnet_imgnet_300k_nodrp_s3

from .simpnet_imgnet_nodrp_600k_s1 import simpnet_imgnet_600k_nodrp_s1
from .simpnet_imgnet_nodrp_600k_s2 import simpnet_imgnet_600k_nodrp_s2
from .simpnet_imgnet_nodrp_600k_s3 import simpnet_imgnet_600k_nodrp_s3

from .simpnet_imgnet_nodrp_1m_s1 import simpnet_imgnet_1m_nodrp_s1
from .simpnet_imgnet_nodrp_1m_s2 import simpnet_imgnet_1m_nodrp_s2
from .simpnet_imgnet_nodrp_1m_s3 import simpnet_imgnet_1m_nodrp_s3
from .simpnet_imgnet_drp_1m_s1 import simpnet_imgnet_1m_drp_s1

#asymetric cnn
from .simpnet_imgnet_nodrp_1m_s1_as import simpnet_imgnet_1m_nodrp_s1_as

from .imagenet_resnet import resnet18, resnet34, resnet50, resnet101, resnet152
