'''
In the name of GOD
SimpNet in Pytorch.
# Strategy 1
# 3L-K3-S2 - repeat 3 times 
# (112 56 28 28 28 14 14 14 14 14  7 7 7 )

'''
import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F

class simpnet_imgnet_5m_drpall_s1_dw(nn.Module):
    def __init__(self, classes=1000, simpnet_name='simpnet_imgnet_5m_drpall_s1_dw'):
        super(simpnet_imgnet_5m_drpall_s1_dw, self).__init__()
        #print(simpnet_name)
        self.features = self._make_layers() 
        self.classifier = nn.Linear(432, classes)

    def load_my_state_dict(self, state_dict):

        own_state = self.state_dict()

        # print(own_state.keys())
        # for name, val in own_state:
        # print(name)
        for name, param in state_dict.items():
            name = name.replace('module.', '')
            if name not in own_state:
                # print(name)
                continue
            if isinstance(param, Parameter):
                # backwards compatibility for serialized parameters
                param = param.data
            print("STATE_DICT: {}".format(name))
            try:
                own_state[name].copy_(param)
            except:
                print('While copying the parameter named {}, whose dimensions in the model are'
                      ' {} and whose dimensions in the checkpoint are {}, ... Using Initial Params'.format(
                    name, own_state[name].size(), param.size()))

    def forward(self, x):
        #print(x.size())
        out = self.features(x)

        #Global Max Pooling
        out = F.max_pool2d(out, kernel_size=out.size()[2:]) 
        out = F.dropout2d(out, 0.000, training=True)

        out = out.view(out.size(0), -1)
        out = self.classifier(out)
        return out

    def _make_layers(self):

        model = nn.Sequential(
                             nn.Conv2d(3, 66, kernel_size=[3, 3], stride=(2, 2), padding=(1, 1)),
                             nn.BatchNorm2d(66, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

                             nn.Conv2d(66, 128, kernel_size=[3, 3], stride=(2, 2), padding=(1, 1)),
                             nn.BatchNorm2d(128, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

                             nn.Conv2d(128, 128, kernel_size=[3, 3], stride=(2, 2), padding=(1, 1)),
                             nn.BatchNorm2d(128, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

							 nn.Conv2d(128, 128, kernel_size=[1, 1]),
                             nn.BatchNorm2d(128, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

                             nn.Conv2d(128, 128, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=128),
                             nn.BatchNorm2d(128, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

							 nn.Conv2d(128, 192, kernel_size=[1, 1]),
                             nn.BatchNorm2d(192, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

                             nn.Conv2d(192, 192, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=192),
                             nn.BatchNorm2d(192, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),


                             nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2), dilation=(1, 1), ceil_mode=False),
                             nn.Dropout2d(p=0.000),


                             nn.Conv2d(192, 192, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=192),
                             nn.BatchNorm2d(192, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

							 nn.Conv2d(192, 192, kernel_size=[1, 1]),
                             nn.BatchNorm2d(192, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.000),
                             
                             nn.Conv2d(192, 192, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=192),
                             nn.BatchNorm2d(192, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

							 nn.Conv2d(192, 192, kernel_size=[1, 1]),
                             nn.BatchNorm2d(192, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.000),

                             nn.Conv2d(192, 192, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=192),
                             nn.BatchNorm2d(192, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

							 nn.Conv2d(192, 192, kernel_size=[1, 1]),
                             nn.BatchNorm2d(192, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.000),

                             nn.Conv2d(192, 192, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=192),
                             nn.BatchNorm2d(192, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

							 nn.Conv2d(192, 192, kernel_size=[1, 1]),
                             nn.BatchNorm2d(192, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.000),

                             nn.Conv2d(192, 288, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(288, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),


                             nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2), dilation=(1, 1), ceil_mode=False),
                             nn.Dropout2d(p=0.000),


                             nn.Conv2d(288, 288, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=288),
                             nn.BatchNorm2d(288, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

							 nn.Conv2d(288, 355, kernel_size=[1, 1]),
                             nn.BatchNorm2d(355, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.000),

                             nn.Conv2d(355, 355, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=355),
                             nn.BatchNorm2d(355, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

							 nn.Conv2d(355, 432, kernel_size=[1, 1]),
                             nn.BatchNorm2d(432, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             #nn.Dropout2d(p=0.000),

                             nn.Conv2d(432, 432, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(432, eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                            )

        for m in self.modules():
          if isinstance(m, nn.Conv2d):
            nn.init.xavier_uniform_(m.weight.data, gain=nn.init.calculate_gain('relu'))

        return model
#param : 3.8Mi 
#Flops =879m
# model = nn.Sequential(
#                              nn.Conv2d(3, 66, kernel_size=[3, 3], stride=(2, 2), padding=(1, 1)),
#                              nn.BatchNorm2d(66, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              nn.Dropout2d(p=0.000),

#                              nn.Conv2d(66, 128, kernel_size=[3, 3], stride=(2, 2), padding=(1, 1)),
#                              nn.BatchNorm2d(128, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              nn.Dropout2d(p=0.000),

#                              nn.Conv2d(128, 128, kernel_size=[3, 3], stride=(2, 2), padding=(1, 1)),
#                              nn.BatchNorm2d(128, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              nn.Dropout2d(p=0.000),

#                              nn.Conv2d(128, 128, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
#                              nn.BatchNorm2d(128, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              nn.Dropout2d(p=0.000),

#                              nn.Conv2d(128, 192, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
#                              nn.BatchNorm2d(192, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),

#                              # nn.Conv2d(192, 384, kernel_size=[1, 1]),
#                              # nn.BatchNorm2d(384, eps=1e-05, momentum=0.05, affine=True),
#                              # nn.ReLU(inplace=True),
#                              #nn.Dropout2d(p=0.000),

#                              nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2), dilation=(1, 1), ceil_mode=False),
#                              nn.Dropout2d(p=0.000),


#                              nn.Conv2d(192, 192, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=192),
#                              nn.BatchNorm2d(192, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              nn.Dropout2d(p=0.000),

# 							 nn.Conv2d(192, 384, kernel_size=[1, 1]),
#                              nn.BatchNorm2d(384, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              #nn.Dropout2d(p=0.000),
                             
#                              nn.Conv2d(384, 384, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=384),
#                              nn.BatchNorm2d(384, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              nn.Dropout2d(p=0.000),

# 							 nn.Conv2d(384, 384, kernel_size=[1, 1]),
#                              nn.BatchNorm2d(384, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              #nn.Dropout2d(p=0.000),

#                              nn.Conv2d(384, 384, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=384),
#                              nn.BatchNorm2d(384, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              nn.Dropout2d(p=0.000),
							 
# 							 nn.Conv2d(384, 384, kernel_size=[1, 1]),
#                              nn.BatchNorm2d(384, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              #nn.Dropout2d(p=0.000),

#                              nn.Conv2d(384, 384, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=384),
#                              nn.BatchNorm2d(384, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              nn.Dropout2d(p=0.000),

# 							 nn.Conv2d(384, 678, kernel_size=[1, 1]),
#                              nn.BatchNorm2d(678, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              #nn.Dropout2d(p=0.000),
                             
#                              nn.Conv2d(678, 678, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=678),
#                              nn.BatchNorm2d(678, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),


#                              nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2), dilation=(1, 1), ceil_mode=False),
#                              nn.Dropout2d(p=0.000),


#                              nn.Conv2d(678, 678, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=678),
#                              nn.BatchNorm2d(678, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              nn.Dropout2d(p=0.000),

# 							 nn.Conv2d(678, 678, kernel_size=[1, 1]),
#                              nn.BatchNorm2d(678, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              #nn.Dropout2d(p=0.000),
                             
#                              nn.Conv2d(678, 678, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1), groups=678),
#                              nn.BatchNorm2d(678, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),

#                              nn.Conv2d(678, 768, kernel_size=[1, 1]),
#                              nn.BatchNorm2d(768, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              #nn.Dropout2d(p=0.000),

#                              nn.Conv2d(768, 768, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1),groups=768),
#                              nn.BatchNorm2d(768, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              nn.Dropout2d(p=0.000),

# 							 nn.Conv2d(768, 900, kernel_size=[1, 1]),
#                              nn.BatchNorm2d(900, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                              #nn.Dropout2d(p=0.000),

#                              nn.Conv2d(900, 900, kernel_size=[3, 3], stride=(1, 1), padding=(1, 1),groups=900),
#                              nn.BatchNorm2d(900, eps=1e-05, momentum=0.05, affine=True),
#                              nn.ReLU(inplace=True),
#                             )