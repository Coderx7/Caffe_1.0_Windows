'''mobilenet_32 in PyTorch.

See the paper "mobilenet_32s: Efficient Convolutional Neural Networks for Mobile Vision Applications"
for more details.
https://github.com/marvis/pytorch-mobilenet_32/blob/master/main.py
'''
import torch
import torch.nn as nn
import torch.nn.functional as F

class mobilenet_32(nn.Module):
    def __init__(self, num_classes=1000):
        super(mobilenet_32, self).__init__()

        def conv_bn(inp, oup, stride):
            return nn.Sequential(
                nn.Conv2d(inp, oup, 3, stride, 1, bias=False),
                nn.BatchNorm2d(oup),
                nn.ReLU(inplace=True)
            )

        def conv_dw(inp, oup, stride):
            return nn.Sequential(
                nn.Conv2d(inp, inp, 3, stride, 1, groups=inp, bias=False),
                nn.BatchNorm2d(inp),
                nn.ReLU(inplace=True),
    
                nn.Conv2d(inp, oup, 1, 1, 0, bias=False),
                nn.BatchNorm2d(oup),
                nn.ReLU(inplace=True),
            )
#since the input is 32/resized to 72/cropped at 64, we changed only one stride in order to retain overall architecture config and
# input colume size throughout network. 
        self.model = nn.Sequential(
            conv_bn(  3,  32, 2),#2
            conv_dw( 32,  64, 1),
            conv_dw( 64, 128, 1),#2
            conv_dw(128, 128, 1),
            conv_dw(128, 256, 2),#2
            conv_dw(256, 256, 1),
            conv_dw(256, 512, 2),#2
            conv_dw(512, 512, 1),
            conv_dw(512, 512, 1),
            conv_dw(512, 512, 1),
            conv_dw(512, 512, 1),
            conv_dw(512, 512, 1),
            conv_dw(512, 1024, 2),#2
            conv_dw(1024, 1024, 1),
            nn.AvgPool2d(7),
        )
        self.fc = nn.Linear(1024, 1000)

    def forward(self, x):
        x = self.model(x)
        x = x.view(-1, 1024)
        x = self.fc(x)
        return x
