'''
In the name of GOD
SimpNet in Pytorch.
# Strategy 1
# 3L-K3-S2 - repeat 3 times 
# (112 56 28 28 28 14 14 14 14 14  7 7 7 )

'''
import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F

class simpnet_imgnet_5m_drpall_s1(nn.Module):
    def __init__(self, classes=1000, scale=1.0, simpnet_name='simpnet_imgnet_5m_drpall_s1'):
        super(simpnet_imgnet_5m_drpall_s1, self).__init__()
        #print(simpnet_name)
    # self.cfg = {
    # 'simpnet5m': [['C', 66], ['C', 128], ['C', 128], ['C', 128], ['C', 192], ['C', 192], ['C', 192], ['C', 192], ['C', 192], ['C', 288], ['P'], ['C', 288], ['C', 355], ['C', 432]],
    # 'simpnet8m': [['C', 128], ['C', 182], ['C', 182], ['C', 182], ['C', 182],  ['C', 182], ['C', 182], ['C', 182], ['C', 182], ['C', 430], ['P'], ['C', 430], ['C', 455], ['C', 600]]}
    # self.scale = scale
    # self.networks = ['simpnet5m', 'simpnet8m']
    # self.network_idx = network_idx
    # self.mode = mode
    # self.strides = {'1': [2, 2, 2, 1, 1],
    #                 '3': [2, 2, 1, 1, 2, 1],
    #                 '4': [2, 2, 1, 2, 1, 1],
    #                 '5': [2, 1, 2, 1, 2, 1],
    #                 '6': [2, 1, 2, 1, 2, 1, 1]}

        self.features = self._make_layers(scale)
        self.classifier = nn.Linear(round(432 * scale), classes)

    def load_my_state_dict(self, state_dict):

        own_state = self.state_dict()

        # print(own_state.keys())
        # for name, val in own_state:
        # print(name)
        for name, param in state_dict.items():
            name = name.replace('module.', '')
            if name not in own_state:
                # print(name)
                continue
            if isinstance(param, Parameter):
                # backwards compatibility for serialized parameters
                param = param.data
            print("STATE_DICT: {}".format(name))
            try:
                own_state[name].copy_(param)
            except:
                print('While copying the parameter named {}, whose dimensions in the model are'
                      ' {} and whose dimensions in the checkpoint are {}, ... Using Initial Params'.format(
                    name, own_state[name].size(), param.size()))

    def forward(self, x):
        #print(x.size())
        out = self.features(x)

        #Global Max Pooling
        out = F.max_pool2d(out, kernel_size=out.size()[2:]) 
        out = F.dropout2d(out, 0.01, training=False)

        out = out.view(out.size(0), -1)
        out = self.classifier(out)
        return out


# def _make_layers2(self, scale=1.0):
#     # cfg = {
#     # 'simpnet5m': [['C', 66], ['C', 128], ['C', 128], ['C', 128], ['C', 192], ['C', 192], ['C', 192], ['C', 192], ['C', 192], ['C', 288], ['P'], ['C', 288], ['C', 355], ['C', 432]],
#     # 'simpnet8m': [['C', 128], ['C', 182], ['C', 182], ['C', 182], ['C', 182],  ['C', 182], ['C', 182], ['C', 182], ['C', 182], ['C', 430], ['P'], ['C', 430], ['C', 455], ['C', 600]]}
#     # scale = 1.0
#     # networks = ['simpnet5m', 'simpnet8m']
#     # network_idx = 0
#     layers = []
#     input_channel = 3
#     idx = 0
#     #mode = '6'
#     # strides = {'1': [2, 2, 2, 1, 1],
#     #            '3': [2, 2, 1, 1, 2, 1],
#     #            '4': [2, 2, 1, 2, 1, 1],
#     #            '5': [2, 1, 2, 1, 2, 1],
#     #            '6': [2, 1, 2, 1, 2, 1, 1]}
    
#     for x in self.cfg[self.networks[self.network_idx]]:
#         if idx == len(self.strides[self.mode]) or x[0] == 'P':
#             layers += [nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2), dilation=(1, 1), ceil_mode=False),
#                        nn.Dropout2d(p=0.00)]
#         if x[0] != 'C':
#             continue
#         filters = x[1]
#         if idx < len(self.strides[self.mode]):
#             stride = self.strides[self.mode][idx]
#         else:
#             stride = 1
#         if idx in (len(self.strides[self.mode])-1, 9, 12):
#             layers += [nn.Conv2d(input_channel, round(filters * scale), kernel_size=[3, 3], stride=(stride, stride), padding=(1, 1)),
#                        nn.BatchNorm2d(round(filters * scale), eps=1e-05, momentum=0.05, affine=True),
#                        nn.ReLU(inplace=True)]
#         else:
#             layers += [nn.Conv2d(input_channel, round(filters * scale), kernel_size=[3, 3], stride=(stride, stride), padding=(1, 1)),
#                        nn.BatchNorm2d(round(filters * scale), eps=1e-05, momentum=0.05, affine=True),
#                        nn.ReLU(inplace=True),
#                        nn.Dropout2d(p=0.000)]
#             input_channel = filters
#         idx += 1

#     # for i in layers:
#     #     print(i, ',')

#     model = nn.Sequential(*layers)

#     for m in self.modules():
#     if isinstance(m, nn.Conv2d):
#         nn.init.xavier_uniform_(m.weight.data, gain=nn.init.calculate_gain('relu'))
#     return model    

    def _make_layers(self, scale=1):

        model = nn.Sequential(
                             nn.Conv2d(3, round(66*scale), kernel_size=[3, 3], stride=(2, 2), padding=(1, 1)),
                             nn.BatchNorm2d(round(66*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

                             nn.Conv2d(round(66*scale), round(128*scale), kernel_size=[3, 3], stride=(2, 2), padding=(1, 1)),
                             nn.BatchNorm2d(round(128*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

                             nn.Conv2d(round(128*scale), round(128*scale), kernel_size=[3, 3], stride=(2, 2), padding=(1, 1)),
                             nn.BatchNorm2d(round(128*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

                             nn.Conv2d(round(128*scale), round(128*scale), kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(round(128*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.000),

                             nn.Conv2d(round(128*scale), round(192*scale), kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(round(192*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),


                             nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2), dilation=(1, 1), ceil_mode=False),
                             nn.Dropout2d(p=0.00),


                             nn.Conv2d(round(192*scale), round(192*scale), kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(round(192*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.0),

                             nn.Conv2d(round(192*scale), round(192*scale), kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(round(192*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.0),

                             nn.Conv2d(round(192*scale),round( 192*scale), kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(round(192*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.0),

                             nn.Conv2d(round(192*scale), round(192*scale), kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(round(192*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.0),

                             nn.Conv2d(round(192*scale), round(288*scale), kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(round(288*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),


                             nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2), dilation=(1, 1), ceil_mode=False),
                             nn.Dropout2d(p=0.00),


                             nn.Conv2d(round(288*scale), round(288*scale), kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(round(288*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.01),

                             nn.Conv2d(round(288*scale), round(355*scale), kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(round(355*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                             nn.Dropout2d(p=0.01),

                             nn.Conv2d(round(355*scale), round(432*scale), kernel_size=[3, 3], stride=(1, 1), padding=(1, 1)),
                             nn.BatchNorm2d(round(432*scale), eps=1e-05, momentum=0.05, affine=True),
                             nn.ReLU(inplace=True),
                            )

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.xavier_uniform_(m.weight.data, gain=nn.init.calculate_gain('relu'))
        return model


    # def _make_layers(self, cfg):
    #     layers = []
    #     in_channels = 3
    #     i=0
    #     for x in cfg:
    #         if x[0] == 'M':
    #             layers += [nn.MaxPool2d(kernel_size=2, stride=2),
    #                        nn.Dropout2d(0.1)]

    #         elif x[0] =='M3':
    #         	layers += [nn.MaxPool2d(kernel_size=2, stride=2),
    #                        nn.Dropout2d(0.1)]
    #         else:
    #             kernel_size = [layer[x[0]][0], layer[x[0]][1]]
    #             stride = layer[x[0]][2]
    #             padding = layer[x[0]][3]
                
    #             if x[1] <= 192*scale:
    #                 drpout_ratio = nn.Dropout2d(0.1)
    #             else:
    #                 drpout_ratio = nn.Dropout2d(0.1)

    #             if (i in (4,9,12)):
    #                 layers += [nn.Conv2d(in_channels, x[1], kernel_size, padding=padding, stride=stride),
    #                            nn.BatchNorm2d(x[1], eps=1e-05, momentum=0.05),
    #                            nn.ReLU(inplace=True)]
    #                 # if (i ==12):
    #                 # lastlayer = layers[-1]
    #                 # layers += [nn.MaxPool2d(kernel_size=lastlayer.size()[2:]),
    #                 #        nn.Dropout2d(0.3)]           
    #             else:
    #                 #print('drp here!',i)
    #                 layers += [nn.Conv2d(in_channels, x[1], kernel_size, padding=padding, stride=stride),
    #                            nn.BatchNorm2d(x[1], eps=1e-05, momentum=0.05),
    #                            nn.ReLU(inplace=True)]
    #                            #,drpout_ratio]

    #             in_channels = x[1]
    #             i =i+1

    #     for m in self.modules():
    #         if isinstance(m, nn.Conv2d):
		  #       # n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
		  #       # m.weight.data.normal_(0, math.sqrt(2. / n))
    #             nn.init.xavier_uniform_(m.weight.data, gain=nn.init.calculate_gain('relu'))
		  #   # elif isinstance(m, nn.BatchNorm2d):
		  #   #     m.weight.data.fill_(1)
		  #   #     m.bias.data.zero_()
    #     return nn.Sequential(*layers)


