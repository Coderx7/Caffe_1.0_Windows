#!/bin/bash
#In the name of God the most compassionate the most merciful 

# training count for each model
ITERATION=2
IMAGENET_DIR=/media/hossein/SSD/ImageNet_DataSet
TRAINING_DIR=train/
VAL_DIR=val/
SAVE_DIR=./snapshots/imagenet/simplenets

EPOCHS=550
BATCH_SIZE=128 #256
#increase t he worker for faster training, 16 to 36+ can be used based on the system you have 
WORKER=16


# 300K Model
ITERATION=1
BATCH_SIZE=512
PRINT_FREQ=200
EPOCHS=900
MODEL_NAME=simpnet_imgnet_300k_nodrp_s1
SAVE_DIR=./snapshots/imagenet/simpnets/300k/nodrp
for (( i=1; i <= $ITERATION; i++ ))
do
python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
   --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT #--start-epoch 0
done


# MODEL_NAME=simpnet_imgnet_300k_nodrp_s2
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE 
# done

# MODEL_NAME=simpnet_imgnet_300k_nodrp_s3
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE 
# done


# 600k Model
# ITERATION=1
# MODEL_NAME=simpnet_imgnet_600k_nodrp_s1
# SAVE_DIR=./snapshots/imagenet/simpnets/600k/nodrp
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE 
# done

# MODEL_NAME=simpnet_imgnet_600k_nodrp_s2
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE 
# done

# MODEL_NAME=simpnet_imgnet_600k_nodrp_s3
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE 
# done


# 1Mil Model
ITERATION=1
BATCH_SIZE=256
PRINT_FREQ=200
EPOCHS=900
MODEL_NAME=simpnet_imgnet_1m_nodrp_s1
SAVE_DIR=./snapshots/imagenet/simpnets/1mil/nodrp
for (( i=1; i <= $ITERATION; i++ ))
do
python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
   --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT #--start-epoch 0
done

# MODEL_NAME=simpnet_imgnet_1m_nodrp_s2
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE 
# done

# MODEL_NAME=simpnet_imgnet_1m_nodrp_s3
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE 
# done




#MODEL_NAME=simpnet_imgnet_5m_nodrp_safc_s1
# CUDA_LAUNCH_BLOCKING=1 python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE



# 5M SimpleNetV1
# MODEL_NAME=simplenet_imagenet
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

# MODEL_NAME=simplenet_imagenet_safc
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

# MODEL_NAME=simplenetv1_imagenet_3p
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done


#5Mil - no drp 
# MODEL_NAME=simpnet_imgnet_5m_nodrp_s1
# SAVE_DIR=./snapshots/imagenet/simpnets/5mil/nodrp
# #CHECKPOINT=./snapshots/imagenet/simpnets/5mil/nodrp/checkpoint.simpnet_imgnet_5m_nodrp_s1.2018-07-04-4882_2018-07-04_20-47-30.pth.tar
# CHECKPOINT=./snapshots/imagenet/simpnets/5mil/nodrp/checkpoint.simpnet_imgnet_5m_nodrp_s1.2018-07-05-6471_2018-07-05_16-47-45.pth.tar
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE --resume $CHECKPOINT 
# done

# #5Mil - SimpleNetV1
#MODEL_NAME=simplenetv1_imagenet_224
MODEL_NAME=simplenetv1_imagenet_3p_v2
SAVE_DIR=./snapshots/imagenet/simplenets/
CHECKPOINT=./snapshots/imagenet/simplenets/chkpt_simplenet_imgnet_06-31-47.pth.tar
BATCH_SIZE=256
PRINT_FREQ=200

# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#    --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE --resume $CHECKPOINT #--start-epoch 0

# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR --print-freq $PRINT_FREQ \
#    --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE --evaluate #--resume $CHECKPOINT #--start-epoch 0


# #5Mil - all drp 
MODEL_NAME=simpnet_imgnet_5m_drpall_s1
SAVE_DIR=./snapshots/imagenet/simpnets/5mil/alldrp
CHECKPOINT=./snapshots/imagenet/simpnets/5mil/alldrp/chkpt_simpnet_imgnet_5m_drpall_s1_2018-09-29_06-31-47.pth.tar
BATCH_SIZE=256
PRINT_FREQ=200
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR --print-freq $PRINT_FREQ \
#    --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE --evaluate #--resume $CHECKPOINT #--start-epoch 0

# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#    --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE --resume $CHECKPOINT #--start-epoch 0

#ODEL_NAME=simpnet_imgnet_5m_drpall_s_3
#MODEL_NAME=simpnet_imgnet_5m_drpall_s_0
MODEL_NAME=simpnet_imgnet_5m_drpall_s_4
# MODEL_NAME=simpnet_imgnet_5m_drpall_s_4_1
# MODEL_NAME=simpnet_imgnet_5m_drpall_s_5
# MODEL_NAME=simpnet_imgnet_5m_drpall_s_6
# MODEL_NAME=simpnet_imgnet_5m_drpall_s_7
SAVE_DIR=./snapshots/imagenet/simpnets/5mil/alldrp
CHECKPOINT=./snapshots/imagenet/simpnets/5mil/alldrp/chkpt_simpnet_imgnet_5m_drpall_s_4_2018-10-08_16-34-13.pth.tarzzz #chkpt_simpnet_imgnet_5m_drpall_s_4_2018-11-08_10-35-53.pth.tar
BATCH_SIZE=256 #batch 256 baese natije behtar va afzayesh deghat shod ama batch 96 na. yaneee ba batch bozorgtar mishe deghat balatar gereft.
#yanee age batch 1024 ya 2048 dahste bashim (5 ta batch 256 ya 6 ta batch (har gpu 256) mesle mobilenet bayad betonim deghatesho bezanim)
PRINT_FREQ=200
EPOCHS=900
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR --print-freq $PRINT_FREQ \
#    --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE --evaluate #--resume $CHECKPOINT #--start-epoch 0

python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
   --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE --resume $CHECKPOINT #--start-epoch 0




# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE --resume $CHECKPOINT  #--start-epoch 0
# done

# #5Mil - all drp 
MODEL_NAME=simpnet_imgnet_5m_drpall_15_s1
SAVE_DIR=./snapshots/imagenet/simpnets/5mil/alldrp_15
CHECKPOINT=./snapshots/imagenet/simpnets/5mil/alldrp_15/chkpt_simpnet_imgnet_5m_drpall_s1_2018-09-16_05-48-45.pth.tar
BATCH_SIZE=256
PRINT_FREQ=200
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR --print-freq $PRINT_FREQ \
#    --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE --evaluate #--resume $CHECKPOINT #--start-epoch 0

# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#    --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT #--start-epoch 0



#mobilenet -
#time 0.37
ITERATION=1
MODEL_NAME=mobilenet
SAVE_DIR=./snapshots/imagenet/mobilenet
CHECKPOINT=./snapshots/imagenet/mobilenet/chkpt_mobilenet_2018-08-11_19-37-23.pth.tar 

 # python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
 #    --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT

# ITERATION=1
# MODEL_NAME=mobilenetv2
# SAVE_DIR=./snapshots/imagenet/mobilenet
# CHECKPOINT=./snapshots/imagenet/mobilenet/chkpt_mobilenet_2018-08-11_19-37-23.pth.tar 

#  python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#     --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT






# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT 
# done

#5Mil - dw_all drp 
# ITERATION=1
# MODEL_NAME=simpnet_imgnet_5m_drpall_s1_dw
# SAVE_DIR=./snapshots/imagenet/simpnets/5mil/alldrp_dw
# CHECKPOINT=./snapshots/imagenet/simpnets/5mil/alldrp_dw/chkpt_simpnet_imgnet_5m_drpall_s1_dw_2018-08-07_18-04-53.pth.tar

# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#    --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE --resume $CHECKPOINT

# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT 
# done



#5Mil - no drp with safc
# MODEL_NAME=simpnet_imgnet_5m_nodrp_safc_s1
# SAVE_DIR=./snapshots/imagenet/simpnets/5mil/nodrp
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

# MODEL_NAME=simpnet_imgnet_5m_nodrp_s2
# SAVE_DIR=./snapshots/imagenet/simpnets/5mil/nodrp
# CHECKPOINT=./snapshots/imagenet/simpnets/5mil/nodrp/best.simpnet_imgnet_5m_nodrp_s2.2018-06-01-9315_2018-06-01_19-44-55.pth.tar

# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE  #--resume $CHECKPOINT --start-epoch 125
# done
# MODEL_NAME=simpnet_imgnet_5m_nodrp_safc_s2
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

# MODEL_NAME=simpnet_imgnet_5m_nodrp_s3
# SAVE_DIR=./snapshots/imagenet/simpnets/5mil/nodrp
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE 
# done
# MODEL_NAME=simpnet_imgnet_5m_nodrp_safc_s3
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

###############################################################################################
#resnet18
# Total params: 11,689,512
# Trainable params: 11,689,512
# Non-trainable params: 0
# ----------------------------------------------------------------
# None
# FLOPs: 1816.41M, Params: 11.69M

# MODEL_NAME=resnet18
# SAVE_DIR=./snapshots/imagenet/resnet
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT
# done
###############################################################################################


#5Mil drpall
# MODEL_NAME=simpnet_imgnet_5m_drpall_s1
# SAVE_DIR=./snapshots/imagenet/simpnets/5mil/drpall
# #SAVE_DIR=./snapshots/imagenet/simpnets/5mil/nodrp
# #CHECKPOINT=./snapshots/imagenet/simpnets/5mil/nodrp/checkpoint.simpnet_imgnet_5m_nodrp_s1.2018-07-04-4882_2018-07-04_20-47-30.pth.tar
# #CHECKPOINT=./snapshots/imagenet/simpnets/5mil/nodrp/checkpoint.simpnet_imgnet_5m_nodrp_s1.2018-07-06-2455_2018-07-06_04-48-17.pth.tar
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT
# done

# MODEL_NAME=simpnet_imgnet_5m_drpall_s2
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

# MODEL_NAME=simpnet_imgnet_5m_drpall_s3
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

#8.9Mil - no drp 
# MODEL_NAME=simpnet_imgnet_8m_nodrp_s1
# SAVE_DIR=./snapshots/imagenet/simpnets/8mil/nodrp
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE $SAVE_DIR/checkpoint.simpnet_imgnet_8m_nodrp_s1.2018-05-20-7077_2018-05-21_00-29-14.pth.tar
# done

#8.9Mil - no drp with safc
# MODEL_NAME=simpnet_imgnet_8m_nodrp_safc_s1
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

# MODEL_NAME=simpnet_imgnet_8m_nodrp_s2
# SAVE_DIR=./snapshots/imagenet/simpnets/8mil/nodrp
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

# MODEL_NAME=simpnet_imgnet_8m_nodrp_safc_s2
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

# MODEL_NAME=simpnet_imgnet_8m_nodrp_safc_s3
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

#8.9Mil drpall
# ================================================================
# Total params: 9,497,719
# Trainable params: 9,497,719
# Non-trainable params: 0
# ----------------------------------------------------------------
# None
# FLOPs: 2065.52M, Params: 9.50M
#time:0.4

# MODEL_NAME=simpnet_imgnet_8m_drpall_s1
# SAVE_DIR=./snapshots/imagenet/simpnets/8mil/drpall
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

# MODEL_NAME=simpnet_imgnet_8m_drpall_s2
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done


# MODEL_NAME=simpnet_imgnet_8m_drpall_s3
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

# 8.9M arch s2
# ================================================================
# Total params: 9,497,719
# Trainable params: 9,497,719
# Non-trainable params: 0
# ----------------------------------------------------------------
# None
# FLOPs: 6151.18M, Params: 9.50M

# MODEL_NAME=simpnet_imgnet_8m_nodrp_s2
# SAVE_DIR=./snapshots/imagenet/simpnets/8mil/nodrp
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE
# done

# MODEL_NAME=simplenetv1_imagenet_3p
# SAVE_DIR=./snapshots/imagenet/simplenets/5mil_3p/
# #CHECKPOINT=./snapshots/imagenet/simplenets/5mil_3p/checkpoint.simplenetv1_imagenet_3p.2018-06-30-9479_2018-06-30_20-40-57.pth.tar #epoch 88 wd 1e-5
# #CHECKPOINT=./snapshots/imagenet/simplenets/5mil_3p/checkpoint.simplenetv1_imagenet_3p.2018-06-20-560_2018-06-20_16-32-19.pth.tar
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT --start-epoch 88
# done


# MODEL_NAME=simpnet_imgnet_1m_nodrp_s1_as
# SAVE_DIR=./snapshots/imagenet/simpnets/1mil/nodrp
# CHECKPOINT=./snapshots/imagenet/simpnets/1mil/nodrp/chkpt_simpnet_imgnet_1m_nodrp_s1_2018-07-08_17-00-55.pth.tar
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT --start-epoch 56
# done


# MODEL_NAME=simpnet_imgnet_1m_drp_s1
# SAVE_DIR=./snapshots/imagenet/simpnets/1mil/drp
# CHECKPOINT=./snapshots/imagenet/simpnets/1mil/nodrp/chkpt_simpnet_imgnet_1m_nodrp_s1_2018-07-08_17-00-55.pth.tar
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT  
# done


# 1mil s1
# Total params: 1,150,786
# Trainable params: 1,150,786
# Non-trainable params: 0
# ----------------------------------------------------------------
# None
# FLOPs: 387.73M, Params: 1.15M
# MODEL_NAME=simpnet_imgnet_1m_nodrp_s1
# SAVE_DIR=./snapshots/imagenet/simpnets/1mil/nodrp
# CHECKPOINT=./snapshots/imagenet/simpnets/1mil/nodrp/chkpt_simpnet_imgnet_1m_nodrp_s1_2018-07-08_17-00-55.pth.tar
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE #--resume $CHECKPOINT --start-epoch 56
# done
# ================================================================
#1mil s2
# Total params: 1,150,786
# Trainable params: 1,150,786
# Non-trainable params: 0
# ----------------------------------------------------------------
# None
# FLOPs: 1080.06M, Params: 1.15M
# MODEL_NAME=simpnet_imgnet_1m_nodrp_s2
# SAVE_DIR=./snapshots/imagenet/simpnets/1mil/nodrp
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE 
# done

# MODEL_NAME=squeezenet1_0
# SAVE_DIR=./snapshots/imagenet/squeezenet/1_0
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE 
# done

# MODEL_NAME=squeezenet1_1
# SAVE_DIR=./snapshots/imagenet/squeezenet/1_1
# for (( i=1; i <= $ITERATION; i++ ))
# do
# python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE 
# done
