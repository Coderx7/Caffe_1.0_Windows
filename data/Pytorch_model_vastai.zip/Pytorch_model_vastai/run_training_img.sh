#In the name of Allah, the most compassionate the most merciful.


IMGNETROOT=/media/hossein/SSD/ImageNet_DataSet
MODEL_NAME=simpnet_imgnet_5m_drpall_s1
#MODEL_NAME=mobilenet2
#MODEL_NAME=simpnet_imgnet_5m_drpall_s4
#MODEL_NAME=mobilenet2
#SAVE_DIR=./snapshots/imagenet/mobilenet/v2
SAVE_DIR=./snapshots/imagenet/simpnets/5mil/alldrp
RESUME_DIR=$SAVE_DIR/2018-11-02_00-12-29/
BATCH_SIZE=512 #512  #256
SCALE=0.5
INPUT_SIZE=224 #160
WORKER=8 #12 #20

python imagenet.py --dataroot $IMGNETROOT --seed 66 --arch $MODEL_NAME --gpus 0 -j $WORKER --scaling $SCALE --input-size $INPUT_SIZE -b $BATCH_SIZE\
 --results_dir $SAVE_DIR --resume $RESUME_DIR