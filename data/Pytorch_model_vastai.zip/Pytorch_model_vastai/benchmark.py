import time
import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
import torchvision.models as models
from torch.autograd import Variable
import models as mdls
import argparse
from utils import convert_model, measure_model
model_names = sorted(name for name in models.__dict__
                     if name.islower() and not name.startswith("__")
                     and callable(models.__dict__[name]))

parser = argparse.ArgumentParser(description='PyTorch ImageNet Training')
parser.add_argument('--bs', default=1, type=int, metavar='N', help='mini-batch size (default: 1)')
parser.add_argument('--gpu', default=False, type=bool, metavar='N', help='run on GPU (default: False)')
args = parser.parse_args()
import os
import platform
import subprocess
import re


# def get_processor_name():
#     if platform.system() == "Windows":
#         return platform.processor()
#     elif platform.system() == "Darwin":
#         os.environ['PATH'] = os.environ['PATH'] + os.pathsep + '/usr/sbin'
#         command = "sysctl -n machdep.cpu.brand_string"
#         return subprocess.check_output(command).strip()
#     elif platform.system() == "Linux":
#         command = "cat /proc/cpuinfo"
#         all_info = subprocess.check_output(command, shell=True).strip()
#         for line in all_info.split("\n"):
#             if "model name" in line:
#                 return re.sub(".*model name.*:", "", line, 1)
#     return ""


# import wmi

# computer = wmi.WMI()
# computer_info = computer.Win32_ComputerSystem()[0]
# os_info = computer.Win32_OperatingSystem()[0]
# proc_info = computer.Win32_Processor()[0]
# gpu_info = computer.Win32_VideoController()[0]

# os_name = os_info.Name.encode('utf-8').split(b'|')[0]
# os_version = ' '.join([os_info.Version, os_info.BuildNumber])
# system_ram = float(os_info.TotalVisibleMemorySize) / 1048576  # KB to GB


def speed(model, name, batch=100, input_size=224):
    t0 = time.time()
    input = torch.rand(batch, 3, input_size, input_size)  # .cuda()
    with torch.no_grad():
        input = Variable(input)  # pytorch v3.0 : input = Variable(input, volatile = True)

        t1 = time.time()
        model(input)
       # torch.cuda.synchronize()
        t2 = time.time()
        model(input)
        # torch.cuda.synchronize()
        t3 = time.time()
    IMAGE_SIZE =input_size    
    n_flops, n_params = measure_model(model, IMAGE_SIZE, IMAGE_SIZE)
    #print_log('' % (n_flops / 1e6, n_params / 1e6), log)
    print('%20s : FLOPs: %.2fM, Params: %.2fM , time: %f' % (name, n_flops / 1e6, n_params / 1e6,  t3 - t2))

def init_model(model, gpu=False):
    if gpu :
        return model.cuda()
    else :
        return model    


if __name__ == '__main__':
    cudnn.benchmark = True  # This will make network slow ??
    # print(get_processor_name())

    # print('OS Name: {0}'.format(os_name))
    # print('OS Version: {0}'.format(os_version))
    # print('CPU: {0}'.format(proc_info.Name))
    # print('RAM: {0} GB'.format(system_ram))
    # print('Graphics Card: {0}'.format(gpu_info.Name))

    gpu = args.gpu

    resnet18 = init_model(models.resnet18(), gpu=gpu)
    resnet50 = init_model(models.resnet50(), gpu=gpu)
    alexnet = init_model(models.alexnet(), gpu=gpu)
    vgg16 = init_model(models.vgg16(), gpu=gpu)  # .cuda()

    # dens1 = init_model(models.densenet121(), gpu=gpu)  # .cuda()
    # dens2 = init_model(models.densenet161(), gpu=gpu)  # .cuda()

    squeezenet = init_model(models.squeezenet1_0(), gpu=gpu)  # .cuda()

    mobilenet = init_model(mdls.mobilenet())  # .cuda()
    mobilenetv2 = init_model(mdls.mobilenet2(scale=1, input_size=224, classes=1000), gpu=gpu)  # .cuda()
    mobilenetv2_14 = init_model(mdls.mobilenet2(scale=1.4, input_size=224, classes=1000), gpu=gpu)  # .cuda()
    mobilenetv2_075 = init_model(mdls.mobilenet2(scale=0.75, input_size=224, classes=1000), gpu=gpu)  # .cuda()
    mobilenetv2_192 = init_model(mdls.mobilenet2(scale=1, input_size=192, classes=1000), gpu=gpu)  # .cuda()
    mobilenetv2_160 = init_model(mdls.mobilenet2(scale=1, input_size=160, classes=1000), gpu=gpu)  # .cuda()

    shufflenet = init_model(mdls.shufflenetv2(scale=1, in_channels=3, c_tag=0.5, num_classes=1000, activation=nn.ReLU, SE=False, residual=False), gpu=gpu) # .cuda()
    shufflenet_05 = init_model(mdls.shufflenetv2(scale=0.5, in_channels=3, c_tag=0.5, num_classes=1000, activation=nn.ReLU, SE=False, residual=False), gpu=gpu) # .cuda()


    simplenetv1 = init_model(mdls.simplenet_imagenet_224(), gpu=gpu)
    simplenet_3p = init_model(mdls.simplenetv1_imagenet_3p(), gpu=gpu)
    simplenet_3p_v2 = init_model(mdls.simplenetv1_imagenet_3p_v2(), gpu=gpu)


    simpnet_1m_s1 = init_model(mdls.simpnet_imgnet_1m_nodrp_s1(), gpu=gpu)
    simpnet_1m_s2 = init_model(mdls.simpnet_imgnet_1m_nodrp_s2(), gpu=gpu)
    simpnet_1m_s4 = init_model(mdls.simpnet_imgnet_1m_drp_s4(), gpu=gpu)
    simpnet_1m_s6 = init_model(mdls.simpnet_imgnet_1m_drp_s6(), gpu=gpu)

    simpnet_300k_s1 = init_model(mdls.simpnet_imgnet_300k_nodrp_s1(), gpu=gpu)
    simpnet_300k_s2 = init_model(mdls.simpnet_imgnet_300k_nodrp_s2(), gpu=gpu)
    simpnet_600k_s1 = init_model(mdls.simpnet_imgnet_600k_nodrp_s1(), gpu=gpu)
    simpnet_600k_s2 = init_model(mdls.simpnet_imgnet_600k_nodrp_s2(), gpu=gpu)

    
    simpnet_58_5_s1 = init_model(mdls.simpnet_imgnet_drpall(mode='1'), gpu=gpu)  # .cuda() 
    simpnet_58_8_s1 = init_model(mdls.simpnet_imgnet_drpall(mode='1', network_idx=1), gpu=gpu)  # .cuda() 

    simpnet_58_5_s3 = init_model(mdls.simpnet_imgnet_drpall(mode='3'), gpu=gpu)  # .cuda() 
    simpnet_58_8_s3 = init_model(mdls.simpnet_imgnet_drpall(mode='3', network_idx=1), gpu=gpu)  # .cuda() 

    simpnet_58_5_s4 = init_model(mdls.simpnet_imgnet_drpall(mode='4'), gpu=gpu)  # .cuda() 
    simpnet_58_8_s4 = init_model(mdls.simpnet_imgnet_drpall(mode='4', network_idx=1), gpu=gpu)  # .cuda() 

    simpnet_58_5_s1_05 = init_model(mdls.simpnet_imgnet_drpall(mode='1', scale=0.5), gpu=gpu)  # .cuda() 
    simpnet_58_8_s1_05 = init_model(mdls.simpnet_imgnet_drpall(mode='1', scale=0.5, network_idx=1), gpu=gpu)  # .cuda() 

    simpnet_58_5_s4_05 = init_model(mdls.simpnet_imgnet_drpall(mode='4', scale=0.5), gpu=gpu)  # .cuda() 
    simpnet_58_8_s4_05 = init_model(mdls.simpnet_imgnet_drpall(mode='4', scale=0.5, network_idx=1), gpu=gpu)  # .cuda() 



    simpnet = init_model(mdls.simpnet_imgnet_5m_drpall_s1(), gpu=gpu)  # .cuda()
    simpnet_144 = init_model(mdls.simpnet_imgnet_5m_drpall_s1(scale=1.44), gpu=gpu ) # .cuda()
    simpnet_075 = init_model(mdls.simpnet_imgnet_5m_drpall_s1(scale=0.75), gpu=gpu)  # .cuda()
    simpnet_05 = init_model(mdls.simpnet_imgnet_5m_drpall_s1(scale=0.5), gpu=gpu)  # .cuda()

    simpnet_s4 = init_model(mdls.simpnet_imgnet_5m_drpall_s4())
    simpnet_s4_144 = init_model(mdls.simpnet_imgnet_5m_drpall_s4(scale=1.44), gpu=gpu )  
    simpnet_s4_075 = init_model(mdls.simpnet_imgnet_5m_drpall_s4(scale=0.75), gpu=gpu)
    simpnet_s4_05 = init_model(mdls.simpnet_imgnet_5m_drpall_s4(scale=0.5), gpu=gpu)

    simpnet_s6 = init_model(mdls.simpnet_imgnet_5m_drpall_s_6(), gpu=gpu)

    simpnet8m = init_model(mdls.simpnet_imgnet_8m_drpall_s1(), gpu=gpu)  # .cuda()
    simpnet8m_s2 = init_model(mdls.simpnet_imgnet_8m_drpall_s2(), gpu=gpu)  # .cuda()
    simpnet8m_s4 = init_model(mdls.simpnet_imgnet_8m_drpall_s4(), gpu=gpu)  # .cuda()
    simpnet8m_s6 = init_model(mdls.simpnet_imgnet_8m_drpall_s6(), gpu=gpu ) # .cuda()

    simpnet_5m_dw = init_model(mdls.simpnet_imgnet_5m_drpall_s1_dw(), gpu=gpu)
    simpnet_5m_dw_s7 = init_model(mdls.simpnet_imgnet_5m_drpall_s7_dw(), gpu=gpu)

    batch = args.bs

    print('stats based on batch of {0}:'.format(batch))
    speed(resnet18, 'resnet18', batch)
    speed(resnet50, 'resnet50', batch)
    speed(alexnet, 'alexnet', batch)
    speed(vgg16, 'vgg16', batch)
    speed(squeezenet, 'squeezenet', batch)
    speed(mobilenet, 'mobilenet', batch)
    speed(mobilenetv2, 'mobilenetv2', batch)
    speed(mobilenetv2_14, 'mobilenetv2_1.4', batch)
    speed(mobilenetv2_075, 'mobilenetv2_0.75', batch)
    speed(mobilenetv2_192, 'mobilenetv2_192', batch)
    speed(mobilenetv2_160, 'mobilenetv2_160', batch)

    speed(shufflenet, 'shufflenet', batch)
    speed(shufflenet_05, 'shufflenet_0.5', batch)

    speed(shufflenet, 'shufflenet  sz190', input_size=192, batch=batch)
    speed(shufflenet_05, 'shufflenet_0.5  sz190', input_size=192, batch=batch)


    speed(simplenet_3p, 'simplenet_3p ', batch)   
    speed(simplenet_3p_v2, 'simplenet_3p_v2 ', batch)  
    speed(simplenetv1, 'simplenetv1 ', batch)    


    speed(simpnet_58_5_s1, 'simpnet_58_5_s1 ', batch)
    speed(simpnet_58_8_s1, 'simpnet_58_8_s1 ', batch)
    speed(simpnet_58_5_s3, 'simpnet_58_5_s3 ', batch)
    speed(simpnet_58_8_s3, 'simpnet_58_8_s3 ', batch)
    speed(simpnet_58_5_s4, 'simpnet_58_5_s4 ', batch)
    speed(simpnet_58_8_s4, 'simpnet_58_8_s4 ', batch)
    speed(simpnet_58_5_s1_05, 'simpnet_58_5_s1_05 ', batch)
    speed(simpnet_58_8_s1_05, 'simpnet_58_8_s1_05 ', batch)
    speed(simpnet_58_5_s4_05, 'simpnet_58_5_s4_05 ', batch)
    speed(simpnet_58_8_s4_05, 'simpnet_58_8_s4_05 ', batch)

    speed(simpnet, 'simpnet5m ', batch)
    speed(simpnet_144, 'simpnet_1.44 ', batch)
    speed(simpnet_075, 'simpnet_0.75 ', batch)
    speed(simpnet_05, 'simpnet_0.5 ', batch)   
     
    speed(simpnet, 'simpnet5m  sz190', input_size=192, batch=batch)
    speed(simpnet, 'simpnet5m  sz160', input_size=192, batch=batch)    
    speed(simpnet_144, 'simpnet_1.44 sz190', input_size=192, batch=batch)
    speed(simpnet_144, 'simpnet_1.44 sz160', input_size=160, batch=batch)   
    speed(simpnet_075, 'simpnet_0.75 sz190', input_size=192, batch=batch)
    speed(simpnet_075, 'simpnet_0.75 sz160', input_size=160, batch=batch)
    speed(simpnet_05, 'simpnet_0.5 sz160', input_size=160, batch=batch)

    speed(simpnet_s4, 'simpnet_s4 ', batch)
    speed(simpnet_s4_144, 'simpnet_s4_1.44 ', batch)
    speed(simpnet_s4_075, 'simpnet_s4_0.75 ', batch)
    speed(simpnet_s4, 'simpnet5m_s4  sz190', input_size=192, batch=batch)
    speed(simpnet_s4, 'simpnet5m_s4  sz160', input_size=192, batch=batch)    
    speed(simpnet_s4_144, 'simpnet_s4_1.44 sz190', input_size=192, batch=batch)
    speed(simpnet_s4_144, 'simpnet_s4_1.44 sz160', input_size=160, batch=batch)   
    speed(simpnet_s4_075, 'simpnet_s4_0.75 sz190', input_size=192, batch=batch)
    speed(simpnet_s4_075, 'simpnet_s4_0.75 sz160', input_size=160, batch=batch)
    speed(simpnet_s4_05, 'simpnet_s4_0.5 sz160', input_size=160, batch=batch)


    speed(simpnet_s6, 'simpnet_s6 ', batch)
    speed(simpnet_5m_dw, 'simpnet_5m_dw', batch)
    speed(simpnet_5m_dw_s7, 'simpnet_5m_dw_s7', batch)

    speed(simpnet_1m_s1, 'simpnet_1m_s1', batch)
    speed(simpnet_1m_s2, 'simpnet_1m_s2', batch)
    speed(simpnet_1m_s4, 'simpnet_1m_s4', batch)
    speed(simpnet_1m_s6, 'simpnet_1m_s6', batch)
    speed(simpnet_300k_s1, 'simpnet_300k_s1', batch)
    speed(simpnet_300k_s2, 'simpnet_300k_s2', batch)
    speed(simpnet_600k_s1, 'simpnet_600k_s1', batch)
    speed(simpnet_600k_s2, 'simpnet_600k_s2', batch)

    speed(simpnet8m, 'simpnet8m_s1', batch)
    speed(simpnet8m_s2, 'simpnet8m_s2', batch)
    speed(simpnet8m_s4, 'simpnet8m_s4', batch)
    speed(simpnet8m_s6, 'simpnet8m_s6', batch)


    # speed(dens1, 'densenet120', batch)
    # speed(dens2, 'densenet160', batch)

# stats based on batch of 1:
#   resnet18 : 0.002798
#   resnet50 : 0.007560
#      vgg16 : 0.009419
# squeezenet : 0.010533
#  mobilenet : 0.006795
#    simpnet : 0.001538
# simpnet8m_s1 : 0.003483
# simpnet8m_s2 : 0.003479

# stats based on batch of 1:
#   resnet18 : 0.437319
#   resnet50 : 0.810584
#    alexnet : 0.144100
#      vgg16 : 2.351701
# squeezenet : 0.189138
#  mobilenet : 0.306226
# mobilenetv2 : 0.364268
# simpnet_1m_s1 : 0.101070
# simpnet_1m_s2 : 0.255185
# simpnet_300k_s1 : 0.034024
# simpnet_300k_s2 : 0.090067
# simpnet_300k_s1 : 0.060044
# simpnet_600k_s2 : 0.148107
#    simpnet : 0.214156
# simpnet8m_s1 : 0.388291
# simpnet8m_s2 : 1.004732
# densenet120 : 0.834602
# densenet160 : 1.871370

# stats based on batch of 10:
#   resnet18 : 0.007697
#   resnet50 : 0.039150
#      vgg16 : 0.045596
# squeezenet : 0.017182
#  mobilenet : 0.019196
#    simpnet : 0.012053
# simpnet8m_s1 : 0.017611
# simpnet8m_s2 : 0.027488

# stats based on batch of 100:
#   resnet18 : 0.061218  ~1,383 MB
#   resnet50 : 0.227528  ~4,649 MB
#      vgg16 : 0.359093  ~6,435 MB
# squeezenet : 0.093850  ~2,185 MB
#  mobilenet : 0.092084  ~2,749 MB
#    simpnet : 0.051098  ~1,475 MB
# simpnet8m_s1 : 0.110911 ~2,899 MB
# simpnet8m_s2 : 0.217452 ~4,263 MB

# stats based on batch of 400:
#   resnet18 : 0.240422
#   resnet50 : 0.886001
#    alexnet : 0.069763
# squeezenet : 0.373501
#  mobilenet : 0.359944
#    simpnet : 0.213498
# simpnet8m_s1 : 0.463346
# simpnet8m_s2 : 0.903685

######################################
########### CPU laptop ###############
# Intel64 Family 6 Model 37 Stepping 5, GenuineIntel
# OS Name: b'Microsoft Windows 10 Enterprise'
# OS Version: 10.0.16299 16299
# CPU: Intel(R) Core(TM) i5 CPU       M 480  @ 2.67GHz
# RAM: 7.68 GB
# Graphics Card: NVIDIA GeForce GT 540M
######################################
# stats based on batch of 1:
#   resnet18 : 0.372271
#   resnet50 : 0.748534
#    alexnet : 0.135100
#      vgg16 : 2.150562
# squeezenet : 0.185135
#  mobilenet : 0.290200
# mobilenetv2 : 0.322238
#    simpnet : 0.195139
# simpnet8m_s1 : 0.349257
# simpnet8m_s2 : 0.909667
# densenet120 : 0.777563
# densenet160 : 1.813312

# stats based on batch of 1:
#   resnet18 : 0.472341
#   resnet50 : 0.916675
#    alexnet : 0.206149
#      vgg16 : 2.531846
# squeezenet : 0.194142
#  mobilenet : 0.356261
# mobilenetv2 : 0.434328
# simpnet_1m_s1 : 0.094070
# simpnet_1m_s2 : 0.275201
# simpnet_300k_s1 : 0.036027
# simpnet_300k_s2 : 0.130096
# simpnet_300k_s1 : 0.065044
# simpnet_600k_s2 : 0.192141
#    simpnet : 0.251184
# simpnet8m_s1 : 0.458337
# simpnet8m_s2 : 1.142827
# densenet120 : 0.899657
# densenet160 : 2.158574

# stats based on batch of 1:
#   resnet18 : 0.372270
#   resnet50 : 0.867640
#    alexnet : 0.138267
#      vgg16 : 2.932128
# squeezenet : 0.303720
#  mobilenet : 0.359762
# mobilenetv2 : 0.421814
#    simpnet : 0.229667
# simpnet8m_s1 : 0.395289
# simpnet8m_s2 : 0.996232
# densenet120 : 0.849628
# densenet160 : 1.963924

# stats based on batch of 10:
#   resnet18 : 3.039212
#   resnet50 : 7.038120
#    alexnet : 1.072778
#      vgg16 : 21.444597
# squeezenet : 1.718249
#  mobilenet : 2.241645
# mobilenetv2 : 2.354713
#    simpnet : 1.894374
# simpnet8m_s1 : 3.331424
# simpnet8m_s2 : 8.797360
# densenet120 : 7.237258

# stats based on batch of 10:
#   resnet18 : 2.803034
#   resnet50 : 6.779932
#    alexnet : 0.989716
#      vgg16 : 22.085062
# squeezenet : 2.365718
#  mobilenet : 2.635920
# mobilenetv2 : 2.838066
#    simpnet : 2.170616
# simpnet8m_s1 : 5.007638
# simpnet8m_s2 : 12.556129
# densenet120 : 7.474437
# densenet160 : 20.045578

# stats based on batch of 10:
#   resnet18 : 3.679637
#   resnet50 : 8.892470
#    alexnet : 1.160845
#      vgg16 : 35.177043
# squeezenet : 2.568367
#  mobilenet : 2.977689
# mobilenetv2 : 3.012708
#    simpnet : 2.818544
# simpnet8m_s1 : 5.031957
# simpnet8m_s2 : 10.672768
# densenet120 : 14.320187
# densenet160 : 22.997382

# stats based on batch of 10:
#   resnet18 : 3.101260
#   resnet50 : 6.793940
#    alexnet : 0.981716
#      vgg16 : 19.873454
# squeezenet : 1.586157
#  mobilenet : 2.091484
# mobilenetv2 : 2.138598
#    simpnet : 1.723255
# simpnet8m_s1 : 3.090253
# simpnet8m_s2 : 8.228982
# densenet120 : 6.764913
# densenet160 : 15.149012


# stats based on batch of 10:
#   resnet18 : 2.681947
#   resnet50 : 6.377633
#    alexnet : 0.937676
#      vgg16 : 18.882713
# squeezenet : 1.497087
#  mobilenet : 2.014463
# mobilenetv2 : 2.007448
# simpnet5m  : 1.702234
# simpnet_5m_dw : 1.262913
# simpnet_1m_s1 : 0.725525
# simpnet_1m_s2 : 1.702235
# simpnet_300k_s1 : 0.263194
# simpnet_300k_s2 : 0.647468
# simpnet_600k_s1 : 0.459334
# simpnet_600k_s2 : 1.136827
# simpnet8m_s1 : 2.965162
# simpnet8m_s2 : 8.035835
# densenet120 : 6.461688
# densenet160 : 14.500534


# D:\CodingStuff\SimpNet_Pytorchh>python benchmark.py --bs 1
# Intel64 Family 6 Model 37 Stepping 5, GenuineIntel
# OS Name: b'Microsoft Windows 10 Enterprise'
# OS Version: 10.0.16299 16299
# CPU: Intel(R) Core(TM) i5 CPU       M 480  @ 2.67GHz
# RAM: 7.678424835205078 GB
# Graphics Card: NVIDIA GeForce GT 540M
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\densenet.py:212: UserWarning: nn.init.kaiming_normal is now deprecated in favor of nn.init.kaiming_normal_.
#   nn.init.kaiming_normal(m.weight.data)
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\squeezenet.py:94: UserWarning: nn.init.kaiming_uniform is now deprecated in favor of nn.init.kaiming_uniform_.
#   init.kaiming_uniform(m.weight.data)
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\squeezenet.py:92: UserWarning: nn.init.normal is now deprecated in favor of nn.init.normal_.
#   init.normal(m.weight.data, mean=0.0, std=0.01)
# stats based on batch of 1:
#             resnet18 : FLOPs: 1816.41M, Params: 11.69M , time: 0.309227
#             resnet50 : FLOPs: 4098.89M, Params: 25.56M , time: 0.737526
#              alexnet : FLOPs: 714.69M, Params: 61.10M , time: 0.118096
#                vgg16 : FLOPs: 15483.83M, Params: 138.36M , time: 2.107527
#           squeezenet : FLOPs: 823.44M, Params: 1.25M , time: 0.172125
#            mobilenet : FLOPs: 573.83M, Params: 4.23M , time: 0.292212
#          mobilenetv2 : FLOPs: 320.19M, Params: 3.51M , time: 0.367267
#           simpnet5m  : FLOPs: 1174.63M, Params: 5.91M , time: 0.183130
#          simpnet_s4  : FLOPs: 1716.95M, Params: 5.91M , time: 0.273197
#          simpnet_s6  : FLOPs: 2975.78M, Params: 5.91M , time: 0.467336
#        simpnet_5m_dw : FLOPs: 636.39M, Params: 3.31M , time: 0.214154
#     simpnet_5m_dw_s7 : FLOPs: 823.42M, Params: 3.23M , time: 0.313229
#        simpnet_1m_s1 : FLOPs: 387.73M, Params: 1.15M , time: 0.085059
#        simpnet_1m_s2 : FLOPs: 1080.06M, Params: 1.15M , time: 0.202145
#        simpnet_1m_s4 : FLOPs: 561.68M, Params: 1.15M , time: 0.129093
#        simpnet_1m_s6 : FLOPs: 1145.05M, Params: 1.15M , time: 0.209152
#      simpnet_300k_s1 : FLOPs: 110.28M, Params: 0.39M , time: 0.034025
#      simpnet_300k_s2 : FLOPs: 307.27M, Params: 0.39M , time: 0.075054
#      simpnet_600k_s1 : FLOPs: 223.01M, Params: 0.72M , time: 0.063046
#      simpnet_600k_s2 : FLOPs: 645.76M, Params: 0.72M , time: 0.181098
#         simpnet8m_s1 : FLOPs: 2065.52M, Params: 9.50M , time: 0.343239
#         simpnet8m_s2 : FLOPs: 6151.18M, Params: 9.50M , time: 0.877636
#          densenet120 : FLOPs: 2850.48M, Params: 7.98M , time: 0.767567
#          densenet160 : FLOPs: 7758.32M, Params: 28.68M , time: 1.714255


# D:\CodingStuff\SimpNet_Pytorchh>python benchmark.py --bs 1
# Intel64 Family 6 Model 37 Stepping 5, GenuineIntel
# OS Name: b'Microsoft Windows 10 Enterprise'
# OS Version: 10.0.16299 16299
# CPU: Intel(R) Core(TM) i5 CPU       M 480  @ 2.67GHz
# RAM: 7.678424835205078 GB
# Graphics Card: NVIDIA GeForce GT 540M
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\densenet.py:212: UserWarning: nn.init.kaiming_normal is now deprecated in favor of nn.init.kaiming_normal_.
#   nn.init.kaiming_normal(m.weight.data)
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\squeezenet.py:94: UserWarning: nn.init.kaiming_uniform is now deprecated in favor of nn.init.kaiming_uniform_.
#   init.kaiming_uniform(m.weight.data)
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\squeezenet.py:92: UserWarning: nn.init.normal is now deprecated in favor of nn.init.normal_.
#   init.normal(m.weight.data, mean=0.0, std=0.01)
# stats based on batch of 1:
#             resnet18 : FLOPs: 1816.41M, Params: 11.69M , time: 0.291214
#             resnet50 : FLOPs: 4098.89M, Params: 25.56M , time: 0.723524
#              alexnet : FLOPs: 714.69M, Params: 61.10M , time: 0.129097
#                vgg16 : FLOPs: 15483.83M, Params: 138.36M , time: 2.047490
#           squeezenet : FLOPs: 823.44M, Params: 1.25M , time: 0.173127

#            mobilenet : FLOPs: 573.83M, Params: 4.23M , time: 0.261194
#          mobilenetv2 : FLOPs: 320.19M, Params: 3.51M , time: 0.312227
#      mobilenetv2_1.4 : FLOPs: 620.54M, Params: 6.11M , time: 0.457327
#     mobilenetv2_0.75 : FLOPs: 222.00M, Params: 2.64M , time: 0.251174
#      mobilenetv2_192 : FLOPs: 320.19M, Params: 3.51M , time: 0.293219
#      mobilenetv2_160 : FLOPs: 320.19M, Params: 3.51M , time: 0.291214

#        simplenet_3p  : FLOPs: 3830.96M, Params: 5.75M , time: 0.526382
#     simplenet_3p_v2  : FLOPs: 1840.82M, Params: 5.75M , time: 0.284208
#         simplenetv1  : FLOPs: 1951.44M, Params: 5.75M , time: 0.288211

#           simpnet5m  : FLOPs: 1174.63M, Params: 5.91M , time: 0.195145
#        simpnet_1.44  : FLOPs: 2414.10M, Params: 11.95M , time: 0.338244
#        simpnet_0.75  : FLOPs: 666.82M, Params: 3.41M , time: 0.111082
#     simpnet5m  sz190 : FLOPs: 1174.63M, Params: 5.91M , time: 0.133097
#     simpnet5m  sz160 : FLOPs: 1174.63M, Params: 5.91M , time: 0.146105
#   simpnet_1.44 sz190 : FLOPs: 2414.10M, Params: 11.95M , time: 0.256185
#   simpnet_1.44 sz160 : FLOPs: 2414.10M, Params: 11.95M , time: 0.178137
#   simpnet_0.75 sz190 : FLOPs: 666.82M, Params: 3.41M , time: 0.084063
#   simpnet_0.75 sz160 : FLOPs: 666.82M, Params: 3.41M , time: 0.080059

#          simpnet_s4  : FLOPs: 1716.95M, Params: 5.91M , time: 0.276201
#          simpnet_s6  : FLOPs: 2975.78M, Params: 5.91M , time: 0.439320
#        simpnet_5m_dw : FLOPs: 636.39M, Params: 3.31M , time: 0.184129
#     simpnet_5m_dw_s7 : FLOPs: 823.42M, Params: 3.23M , time: 0.294215
#        simpnet_1m_s1 : FLOPs: 387.73M, Params: 1.15M , time: 0.085064
#        simpnet_1m_s2 : FLOPs: 1080.06M, Params: 1.15M , time: 0.193141
#        simpnet_1m_s4 : FLOPs: 561.68M, Params: 1.15M , time: 0.108078
#        simpnet_1m_s6 : FLOPs: 1145.05M, Params: 1.15M , time: 0.225165
#      simpnet_300k_s1 : FLOPs: 110.28M, Params: 0.39M , time: 0.034024
#      simpnet_300k_s2 : FLOPs: 307.27M, Params: 0.39M , time: 0.083061
#      simpnet_600k_s1 : FLOPs: 223.01M, Params: 0.72M , time: 0.053039
#      simpnet_600k_s2 : FLOPs: 645.76M, Params: 0.72M , time: 0.125089
#         simpnet8m_s1 : FLOPs: 2065.52M, Params: 9.50M , time: 0.338246
#         simpnet8m_s2 : FLOPs: 6151.18M, Params: 9.50M , time: 0.837625
#         simpnet8m_s4 : FLOPs: 2942.52M, Params: 9.50M , time: 0.435308
#         simpnet8m_s6 : FLOPs: 5793.74M, Params: 9.50M , time: 0.793582
#          densenet120 : FLOPs: 2850.48M, Params: 7.98M , time: 0.736105
#          densenet160 : FLOPs: 7758.32M, Params: 28.68M , time: 1.673242

#################################################################################

# D:\CodingStuff\SimpNet_Pytorchh>python benchmark.py --bs 10
# Intel64 Family 6 Model 37 Stepping 5, GenuineIntel
# OS Name: b'Microsoft Windows 10 Enterprise'
# OS Version: 10.0.16299 16299
# CPU: Intel(R) Core(TM) i5 CPU       M 480  @ 2.67GHz
# RAM: 7.678424835205078 GB
# Graphics Card: NVIDIA GeForce GT 540M
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\densenet.py:212: UserWarning: nn.init.kaiming_normal is now deprecated in favor of nn.init.kaiming_normal_.
#   nn.init.kaiming_normal(m.weight.data)
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\squeezenet.py:94: UserWarning: nn.init.kaiming_uniform is now deprecated in favor of nn.init.kaiming_uniform_.
#   init.kaiming_uniform(m.weight.data)
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\squeezenet.py:92: UserWarning: nn.init.normal is now deprecated in favor of nn.init.normal_.
#   init.normal(m.weight.data, mean=0.0, std=0.01)
# stats based on batch of 10:
#             resnet18 : FLOPs: 1816.41M, Params: 11.69M , time: 2.598895
#             resnet50 : FLOPs: 4098.89M, Params: 25.56M , time: 6.315604
#              alexnet : FLOPs: 714.69M, Params: 61.10M , time: 0.914663
#                vgg16 : FLOPs: 15483.83M, Params: 138.36M , time: 19.436177
#           squeezenet : FLOPs: 823.44M, Params: 1.25M , time: 1.457063
#            mobilenet : FLOPs: 573.83M, Params: 4.23M , time: 1.988452
#          mobilenetv2 : FLOPs: 320.19M, Params: 3.51M , time: 2.039486

#      mobilenetv2_1.4 : FLOPs: 620.54M, Params: 6.11M , time: 2.996185
#     mobilenetv2_0.75 : FLOPs: 222.00M, Params: 2.64M , time: 1.617174
#      mobilenetv2_192 : FLOPs: 320.19M, Params: 3.51M , time: 2.077515
#      mobilenetv2_160 : FLOPs: 320.19M, Params: 3.51M , time: 2.087983

#        simplenet_3p  : FLOPs: 3830.96M, Params: 5.75M , time: 5.080705
#     simplenet_3p_v2  : FLOPs: 1840.82M, Params: 5.75M , time: 2.514848
#         simplenetv1  : FLOPs: 1951.44M, Params: 5.75M , time: 2.799037

#           simpnet5m  : FLOPs: 1174.63M, Params: 5.91M , time: 1.699239
#        simpnet_1.44  : FLOPs: 2414.10M, Params: 11.95M , time: 3.489064
#        simpnet_0.75  : FLOPs: 666.82M, Params: 3.41M , time: 1.016743
#     simpnet5m  sz190 : FLOPs: 1174.63M, Params: 5.91M , time: 1.283938
#     simpnet5m  sz160 : FLOPs: 1174.63M, Params: 5.91M , time: 1.268923
#   simpnet_1.44 sz190 : FLOPs: 2414.10M, Params: 11.95M , time: 2.282670
#   simpnet_1.44 sz160 : FLOPs: 2414.10M, Params: 11.95M , time: 1.811332
#   simpnet_0.75 sz190 : FLOPs: 666.82M, Params: 3.41M , time: 0.741539
#   simpnet_0.75 sz160 : FLOPs: 666.82M, Params: 3.41M , time: 0.558408
#          simpnet_s4  : FLOPs: 1716.95M, Params: 5.91M , time: 2.389743
#          simpnet_s6  : FLOPs: 2975.78M, Params: 5.91M , time: 4.177047

#        simpnet_5m_dw : FLOPs: 636.39M, Params: 3.31M , time: 1.285959
#     simpnet_5m_dw_s7 : FLOPs: 823.42M, Params: 3.23M , time: 2.891107

#        simpnet_1m_s1 : FLOPs: 387.73M, Params: 1.15M , time: 0.716523
#        simpnet_1m_s2 : FLOPs: 1080.06M, Params: 1.15M , time: 1.747275
#        simpnet_1m_s4 : FLOPs: 561.68M, Params: 1.15M , time: 1.102803
#        simpnet_1m_s6 : FLOPs: 1145.05M, Params: 1.15M , time: 1.811335

#      simpnet_300k_s1 : FLOPs: 110.28M, Params: 0.39M , time: 0.275199
#      simpnet_300k_s2 : FLOPs: 307.27M, Params: 0.39M , time: 0.640467
#      simpnet_600k_s1 : FLOPs: 223.01M, Params: 0.72M , time: 0.422304
#      simpnet_600k_s2 : FLOPs: 645.76M, Params: 0.72M , time: 1.126822

#         simpnet8m_s1 : FLOPs: 2065.52M, Params: 9.50M , time: 2.926133
#         simpnet8m_s2 : FLOPs: 6151.18M, Params: 9.50M , time: 7.929780
#         simpnet8m_s4 : FLOPs: 2942.52M, Params: 9.50M , time: 4.081977
#         simpnet8m_s6 : FLOPs: 5793.74M, Params: 9.50M , time: 7.638649

#          densenet120 : FLOPs: 2850.48M, Params: 7.98M , time: 6.672755
#          densenet160 : FLOPs: 7758.32M, Params: 28.68M , time: 15.038981



# D:\CodingStuff\SimpNet_Pytorchh>python benchmark.py --bs 10
# Intel64 Family 6 Model 37 Stepping 5, GenuineIntel
# OS Name: b'Microsoft Windows 10 Enterprise'
# OS Version: 10.0.16299 16299
# CPU: Intel(R) Core(TM) i5 CPU       M 480  @ 2.67GHz
# RAM: 7.678424835205078 GB
# Graphics Card: NVIDIA GeForce GT 540M
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\densenet.py:212: UserWarning: nn.init.kaiming_normal is now deprecated in favor of nn.init.kaiming_normal_.
#   nn.init.kaiming_normal(m.weight.data)
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\squeezenet.py:94: UserWarning: nn.init.kaiming_uniform is now deprecated in favor of nn.init.kaiming_uniform_.
#   init.kaiming_uniform(m.weight.data)
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\squeezenet.py:92: UserWarning: nn.init.normal is now deprecated in favor of nn.init.normal_.
#   init.normal(m.weight.data, mean=0.0, std=0.01)
# stats based on batch of 10:
#             resnet18 : FLOPs: 1816.41M, Params: 11.69M , time: 2.568873
#             resnet50 : FLOPs: 4098.89M, Params: 25.56M , time: 6.041406
#              alexnet : FLOPs: 714.69M, Params: 61.10M , time: 0.861631
#                vgg16 : FLOPs: 15483.83M, Params: 138.36M , time: 18.226650
#           squeezenet : FLOPs: 823.44M, Params: 1.25M , time: 1.501095
#            mobilenet : FLOPs: 573.83M, Params: 4.23M , time: 1.938413
#          mobilenetv2 : FLOPs: 320.19M, Params: 3.51M , time: 1.924398
#      mobilenetv2_1.4 : FLOPs: 620.54M, Params: 6.11M , time: 2.968164
#     mobilenetv2_0.75 : FLOPs: 222.00M, Params: 2.64M , time: 1.687227
#      mobilenetv2_192 : FLOPs: 320.19M, Params: 3.51M , time: 2.013472
#      mobilenetv2_160 : FLOPs: 320.19M, Params: 3.51M , time: 2.019478

#        simplenet_3p  : FLOPs: 3830.96M, Params: 5.75M , time: 4.646386
#     simplenet_3p_v2  : FLOPs: 1840.82M, Params: 5.75M , time: 2.390743
#         simplenetv1  : FLOPs: 1951.44M, Params: 5.75M , time: 2.567868

#           simpnet5m  : FLOPs: 1174.63M, Params: 5.91M , time: 1.571152
#        simpnet_1.44  : FLOPs: 2414.10M, Params: 11.95M , time: 2.989179
#        simpnet_0.75  : FLOPs: 666.82M, Params: 3.41M , time: 0.955700
#     simpnet5m  sz190 : FLOPs: 1174.63M, Params: 5.91M , time: 1.174857
#     simpnet5m  sz160 : FLOPs: 1174.63M, Params: 5.91M , time: 1.177858

#   simpnet_1.44 sz190 : FLOPs: 2414.10M, Params: 11.95M , time: 2.218614
#   simpnet_1.44 sz160 : FLOPs: 2414.10M, Params: 11.95M , time: 1.577153
#   simpnet_0.75 sz190 : FLOPs: 666.82M, Params: 3.41M , time: 0.724531
#   simpnet_0.75 sz160 : FLOPs: 666.82M, Params: 3.41M , time: 0.577417
#          simpnet_s4  : FLOPs: 1716.95M, Params: 5.91M , time: 2.210607
#     simpnet_s4_1.44  : FLOPs: 3534.48M, Params: 11.95M , time: 4.454251
#     simpnet_s4_0.75  : FLOPs: 971.95M, Params: 3.41M , time: 1.426037
#  simpnet5m_s4  sz190 : FLOPs: 1716.95M, Params: 5.91M , time: 1.660215
#  simpnet5m_s4  sz160 : FLOPs: 1716.95M, Params: 5.91M , time: 1.693231
# simpnet_s4_1.44 sz190 : FLOPs: 3534.48M, Params: 11.95M , time: 3.238360
# simpnet_s4_1.44 sz160 : FLOPs: 3534.48M, Params: 11.95M , time: 2.282667
# simpnet_s4_0.75 sz190 : FLOPs: 971.95M, Params: 3.41M , time: 1.006735
# simpnet_s4_0.75 sz160 : FLOPs: 971.95M, Params: 3.41M , time: 0.714526

#          simpnet_s6  : FLOPs: 2975.78M, Params: 5.91M , time: 3.916857
#        simpnet_5m_dw : FLOPs: 636.39M, Params: 3.31M , time: 1.166853
#     simpnet_5m_dw_s7 : FLOPs: 823.42M, Params: 3.23M , time: 2.894109
#        simpnet_1m_s1 : FLOPs: 387.73M, Params: 1.15M , time: 0.721526
#        simpnet_1m_s2 : FLOPs: 1080.06M, Params: 1.15M , time: 1.696237
#        simpnet_1m_s4 : FLOPs: 561.68M, Params: 1.15M , time: 0.959696
#        simpnet_1m_s6 : FLOPs: 1145.05M, Params: 1.15M , time: 1.788305

#      simpnet_300k_s1 : FLOPs: 110.28M, Params: 0.39M , time: 0.261194
#      simpnet_300k_s2 : FLOPs: 307.27M, Params: 0.39M , time: 0.603440
#      simpnet_600k_s1 : FLOPs: 223.01M, Params: 0.72M , time: 0.423311
#      simpnet_600k_s2 : FLOPs: 645.76M, Params: 0.72M , time: 1.091760

#         simpnet8m_s1 : FLOPs: 2065.52M, Params: 9.50M , time: 2.788033
#         simpnet8m_s2 : FLOPs: 6151.18M, Params: 9.50M , time: 7.649573
#         simpnet8m_s4 : FLOPs: 2942.52M, Params: 9.50M , time: 3.734725
#         simpnet8m_s6 : FLOPs: 5793.74M, Params: 9.50M , time: 7.726634

#          densenet120 : FLOPs: 2850.48M, Params: 7.98M , time: 6.293111
#          densenet160 : FLOPs: 7758.32M, Params: 28.68M , time: 14.300290




######################################## 11/4/2018##################################
# D:\CodingStuff\SimpNet_Pytorchh>python benchmark.py --bs 1
# Intel64 Family 6 Model 37 Stepping 5, GenuineIntel
# OS Name: b'Microsoft Windows 10 Enterprise'
# OS Version: 10.0.16299 16299
# CPU: Intel(R) Core(TM) i5 CPU       M 480  @ 2.67GHz
# RAM: 7.678424835205078 GB
# Graphics Card: NVIDIA GeForce GT 540M
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\densenet.py:212: UserWarning: nn.init.kaiming_normal is now deprecated in favor of nn.init.kaiming_normal_.
#   nn.init.kaiming_normal(m.weight.data)
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\squeezenet.py:94: UserWarning: nn.init.kaiming_uniform is now deprecated in favor of nn.init.kaiming_uniform_.
#   init.kaiming_uniform(m.weight.data)
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\squeezenet.py:92: UserWarning: nn.init.normal is now deprecated in favor of nn.init.normal_.
#   init.normal(m.weight.data, mean=0.0, std=0.01)
# stats based on batch of 1:
#             resnet18 : FLOPs: 1816.41M, Params: 11.69M , time: 0.379274
#             resnet50 : FLOPs: 4098.89M, Params: 25.56M , time: 1.008733
#              alexnet : FLOPs: 714.69M, Params: 61.10M , time: 0.464336
#                vgg16 : FLOPs: 15483.83M, Params: 138.36M , time: 6.365649
#           squeezenet : FLOPs: 823.44M, Params: 1.25M , time: 0.467839
#            mobilenet : FLOPs: 573.83M, Params: 4.23M , time: 0.467341
#          mobilenetv2 : FLOPs: 320.19M, Params: 3.51M , time: 0.665483
#      mobilenetv2_1.4 : FLOPs: 620.54M, Params: 6.11M , time: 1.247921
#     mobilenetv2_0.75 : FLOPs: 222.00M, Params: 2.64M , time: 0.586927
#      mobilenetv2_192 : FLOPs: 320.19M, Params: 3.51M , time: 0.797575
#      mobilenetv2_160 : FLOPs: 320.19M, Params: 3.51M , time: 0.573916
#           shufflenet : FLOPs: 149.51M, Params: 2.31M , time: 0.270695
#       shufflenet_0.5 : FLOPs: 42.29M, Params: 1.37M , time: 0.121592
#    shufflenet  sz190 : FLOPs: 110.11M, Params: 2.31M , time: 0.172125
# shufflenet_0.5  sz190 : FLOPs: 31.33M, Params: 1.37M , time: 0.111082
#        simplenet_3p  : FLOPs: 3830.96M, Params: 5.75M , time: 1.032250
#     simplenet_3p_v2  : FLOPs: 1840.82M, Params: 5.75M , time: 0.577417
#         simplenetv1  : FLOPs: 1951.44M, Params: 5.75M , time: 0.553402
#           simpnet5m  : FLOPs: 1174.63M, Params: 5.91M , time: 0.335745
#        simpnet_1.44  : FLOPs: 2414.10M, Params: 11.95M , time: 0.667984
#        simpnet_0.75  : FLOPs: 666.82M, Params: 3.41M , time: 0.257186
#         simpnet_0.5  : FLOPs: 299.90M, Params: 1.59M , time: 0.118587
#     simpnet5m  sz190 : FLOPs: 863.11M, Params: 5.91M , time: 0.327237
#     simpnet5m  sz160 : FLOPs: 863.11M, Params: 5.91M , time: 0.275703
#   simpnet_1.44 sz190 : FLOPs: 1773.79M, Params: 11.95M , time: 0.476348
#   simpnet_1.44 sz160 : FLOPs: 1231.99M, Params: 11.95M , time: 0.338747
#   simpnet_0.75 sz190 : FLOPs: 490.00M, Params: 3.41M , time: 0.214154
#   simpnet_0.75 sz160 : FLOPs: 340.37M, Params: 3.41M , time: 0.168623
#    simpnet_0.5 sz160 : FLOPs: 153.11M, Params: 1.59M , time: 0.065547
#          simpnet_s4  : FLOPs: 1716.95M, Params: 5.91M , time: 0.390287
#     simpnet_s4_1.44  : FLOPs: 3534.48M, Params: 11.95M , time: 0.826098
#     simpnet_s4_0.75  : FLOPs: 971.95M, Params: 3.41M , time: 0.372773
#  simpnet5m_s4  sz190 : FLOPs: 1261.55M, Params: 5.91M , time: 0.361259
#  simpnet5m_s4  sz160 : FLOPs: 1261.55M, Params: 5.91M , time: 0.333244
# simpnet_s4_1.44 sz190 : FLOPs: 2596.92M, Params: 11.95M , time: 0.742541
# simpnet_s4_1.44 sz160 : FLOPs: 1803.61M, Params: 11.95M , time: 0.471344
# simpnet_s4_0.75 sz190 : FLOPs: 714.17M, Params: 3.41M , time: 0.185636
# simpnet_s4_0.75 sz160 : FLOPs: 496.05M, Params: 3.41M , time: 0.130095
# simpnet_s4_0.5 sz160 : FLOPs: 222.34M, Params: 1.59M , time: 0.082060
#          simpnet_s6  : FLOPs: 2975.78M, Params: 5.91M , time: 0.812095
#        simpnet_5m_dw : FLOPs: 636.39M, Params: 3.31M , time: 0.357753
#     simpnet_5m_dw_s7 : FLOPs: 823.42M, Params: 3.23M , time: 0.582923
#        simpnet_1m_s1 : FLOPs: 387.73M, Params: 1.15M , time: 0.167621
#        simpnet_1m_s2 : FLOPs: 1080.06M, Params: 1.15M , time: 0.403792
#        simpnet_1m_s4 : FLOPs: 561.68M, Params: 1.15M , time: 0.204648
#        simpnet_1m_s6 : FLOPs: 1145.05M, Params: 1.15M , time: 0.372272
#      simpnet_300k_s1 : FLOPs: 110.28M, Params: 0.39M , time: 0.136100
#      simpnet_300k_s2 : FLOPs: 307.27M, Params: 0.39M , time: 0.125593
#      simpnet_600k_s1 : FLOPs: 223.01M, Params: 0.72M , time: 0.126591
#      simpnet_600k_s2 : FLOPs: 645.76M, Params: 0.72M , time: 0.283706
#         simpnet8m_s1 : FLOPs: 2065.52M, Params: 9.50M , time: 0.826599
#         simpnet8m_s2 : FLOPs: 6151.18M, Params: 9.50M , time: 1.864354
#         simpnet8m_s4 : FLOPs: 2942.52M, Params: 9.50M , time: 0.944185
#         simpnet8m_s6 : FLOPs: 5793.74M, Params: 9.50M , time: 1.539629
#          densenet120 : FLOPs: 2850.48M, Params: 7.98M , time: 1.532115
#          densenet160 : FLOPs: 7758.32M, Params: 28.68M , time: 3.973886

# D:\CodingStuff\SimpNet_Pytorchh>python benchmark.py --bs 1
# Intel64 Family 6 Model 37 Stepping 5, GenuineIntel
# OS Name: b'Microsoft Windows 10 Enterprise'
# OS Version: 10.0.16299 16299
# CPU: Intel(R) Core(TM) i5 CPU       M 480  @ 2.67GHz
# RAM: 7.678424835205078 GB
# Graphics Card: NVIDIA GeForce GT 540M
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\densenet.py:212: UserWarning: nn.init.kaiming_normal is now deprecated in favor of nn.init.kaiming_normal_.
#   nn.init.kaiming_normal(m.weight.data)
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\squeezenet.py:94: UserWarning: nn.init.kaiming_uniform is now deprecated in favor of nn.init.kaiming_uniform_.
#   init.kaiming_uniform(m.weight.data)
# C:\Users\Seyyed\Anaconda3\lib\site-packages\torchvision\models\squeezenet.py:92: UserWarning: nn.init.normal is now deprecated in favor of nn.init.normal_.
#   init.normal(m.weight.data, mean=0.0, std=0.01)
# stats based on batch of 1:
#             resnet18 : FLOPs: 1816.41M, Params: 11.69M , time: 0.558906
#             resnet50 : FLOPs: 4098.89M, Params: 25.56M , time: 1.571143
#              alexnet : FLOPs: 714.69M, Params: 61.10M , time: 0.218654
#                vgg16 : FLOPs: 15483.83M, Params: 138.36M , time: 3.842294
#           squeezenet : FLOPs: 823.44M, Params: 1.25M , time: 0.360261
#            mobilenet : FLOPs: 573.83M, Params: 4.23M , time: 0.645973
#          mobilenetv2 : FLOPs: 320.19M, Params: 3.51M , time: 0.624439
#      mobilenetv2_1.4 : FLOPs: 620.54M, Params: 6.11M , time: 0.787570
#     mobilenetv2_0.75 : FLOPs: 222.00M, Params: 2.64M , time: 0.494358
#      mobilenetv2_192 : FLOPs: 320.19M, Params: 3.51M , time: 0.561910
#      mobilenetv2_160 : FLOPs: 320.19M, Params: 3.51M , time: 0.567411
#           shufflenet : FLOPs: 149.51M, Params: 2.31M , time: 0.261694
#       shufflenet_0.5 : FLOPs: 42.29M, Params: 1.37M , time: 0.133087
#    shufflenet  sz190 : FLOPs: 110.11M, Params: 2.31M , time: 0.192642
# shufflenet_0.5  sz190 : FLOPs: 31.33M, Params: 1.37M , time: 0.121089
#        simplenet_3p  : FLOPs: 3830.96M, Params: 5.75M , time: 1.173351
#     simplenet_3p_v2  : FLOPs: 1840.82M, Params: 5.75M , time: 0.491858
#         simplenetv1  : FLOPs: 1951.44M, Params: 5.75M , time: 0.569412
#           simpnet5m  : FLOPs: 1174.63M, Params: 5.91M , time: 0.317730
#        simpnet_1.44  : FLOPs: 2414.10M, Params: 11.95M , time: 0.681493
#        simpnet_0.75  : FLOPs: 666.82M, Params: 3.41M , time: 0.207651
#         simpnet_0.5  : FLOPs: 299.90M, Params: 1.59M , time: 0.108075
#     simpnet5m  sz190 : FLOPs: 863.11M, Params: 5.91M , time: 0.240178
#     simpnet5m  sz160 : FLOPs: 863.11M, Params: 5.91M , time: 0.240177
#   simpnet_1.44 sz190 : FLOPs: 1773.79M, Params: 11.95M , time: 0.521879
#   simpnet_1.44 sz160 : FLOPs: 1231.99M, Params: 11.95M , time: 0.486352
#   simpnet_0.75 sz190 : FLOPs: 490.00M, Params: 3.41M , time: 0.220660
#   simpnet_0.75 sz160 : FLOPs: 340.37M, Params: 3.41M , time: 0.150108
#    simpnet_0.5 sz160 : FLOPs: 153.11M, Params: 1.59M , time: 0.076556
#          simpnet_s4  : FLOPs: 1716.95M, Params: 5.91M , time: 0.414299
#     simpnet_s4_1.44  : FLOPs: 3534.48M, Params: 11.95M , time: 0.968705
#     simpnet_s4_0.75  : FLOPs: 971.95M, Params: 3.41M , time: 0.387281
#  simpnet5m_s4  sz190 : FLOPs: 1261.55M, Params: 5.91M , time: 0.496859
#  simpnet5m_s4  sz160 : FLOPs: 1261.55M, Params: 5.91M , time: 0.398289
# simpnet_s4_1.44 sz190 : FLOPs: 2596.92M, Params: 11.95M , time: 0.668486
# simpnet_s4_1.44 sz160 : FLOPs: 1803.61M, Params: 11.95M , time: 0.534893
# simpnet_s4_0.75 sz190 : FLOPs: 714.17M, Params: 3.41M , time: 0.241675
# simpnet_s4_0.75 sz160 : FLOPs: 496.05M, Params: 3.41M , time: 0.141607
# simpnet_s4_0.5 sz160 : FLOPs: 222.34M, Params: 1.59M , time: 0.085064
#          simpnet_s6  : FLOPs: 2975.78M, Params: 5.91M , time: 0.922666
#        simpnet_5m_dw : FLOPs: 636.39M, Params: 3.31M , time: 0.335243
#     simpnet_5m_dw_s7 : FLOPs: 823.42M, Params: 3.23M , time: 0.583924
#        simpnet_1m_s1 : FLOPs: 387.73M, Params: 1.15M , time: 0.225164
#        simpnet_1m_s2 : FLOPs: 1080.06M, Params: 1.15M , time: 0.461833
#        simpnet_1m_s4 : FLOPs: 561.68M, Params: 1.15M , time: 0.208150
#        simpnet_1m_s6 : FLOPs: 1145.05M, Params: 1.15M , time: 0.408296
#      simpnet_300k_s1 : FLOPs: 110.28M, Params: 0.39M , time: 0.063545
#      simpnet_300k_s2 : FLOPs: 307.27M, Params: 0.39M , time: 0.166622
#      simpnet_600k_s1 : FLOPs: 223.01M, Params: 0.72M , time: 0.100072
#      simpnet_600k_s2 : FLOPs: 645.76M, Params: 0.72M , time: 0.245679
#         simpnet8m_s1 : FLOPs: 2065.52M, Params: 9.50M , time: 0.985214
#         simpnet8m_s2 : FLOPs: 6151.18M, Params: 9.50M , time: 1.463064
#         simpnet8m_s4 : FLOPs: 2942.52M, Params: 9.50M , time: 0.825594
#         simpnet8m_s6 : FLOPs: 5793.74M, Params: 9.50M , time: 1.888376
#          densenet120 : FLOPs: 2850.48M, Params: 7.98M , time: 1.010908
#          densenet160 : FLOPs: 7758.32M, Params: 28.68M , time: 2.202680





######################Corei7 4790K 19/nov/2018
# stats based on batch of 1:
#             resnet18 : FLOPs: 1816.41M, Params: 11.69M , time: 0.073444
#             resnet50 : FLOPs: 4098.89M, Params: 25.56M , time: 0.162978
#              alexnet : FLOPs: 714.69M, Params: 61.10M , time: 0.034940
#                vgg16 : FLOPs: 15483.83M, Params: 138.36M , time: 0.459418
#           squeezenet : FLOPs: 823.44M, Params: 1.25M , time: 0.043911
#            mobilenet : FLOPs: 573.83M, Params: 4.23M , time: 0.096430
#          mobilenetv2 : FLOPs: 320.19M, Params: 3.51M , time: 0.106907
#      mobilenetv2_1.4 : FLOPs: 620.54M, Params: 6.11M , time: 0.154380
#     mobilenetv2_0.75 : FLOPs: 222.00M, Params: 2.64M , time: 0.087310
#      mobilenetv2_192 : FLOPs: 320.19M, Params: 3.51M , time: 0.110597
#      mobilenetv2_160 : FLOPs: 320.19M, Params: 3.51M , time: 0.107497
#           shufflenet : FLOPs: 149.51M, Params: 2.31M , time: 0.047379
#       shufflenet_0.5 : FLOPs: 42.29M, Params: 1.37M , time: 0.026437
#    shufflenet  sz190 : FLOPs: 110.11M, Params: 2.31M , time: 0.043162
# shufflenet_0.5  sz190 : FLOPs: 31.33M, Params: 1.37M , time: 0.022717
#        simplenet_3p  : FLOPs: 3830.96M, Params: 5.75M , time: 0.108119
#     simplenet_3p_v2  : FLOPs: 1840.82M, Params: 5.75M , time: 0.061193
#         simplenetv1  : FLOPs: 1951.44M, Params: 5.75M , time: 0.067885
#     simpnet_58_5_s1  : FLOPs: 1174.63M, Params: 5.91M , time: 0.046141
#     simpnet_58_8_s1  : FLOPs: 2065.52M, Params: 9.50M , time: 0.080469
#     simpnet_58_5_s3  : FLOPs: 2064.07M, Params: 5.91M , time: 0.068771
#     simpnet_58_8_s3  : FLOPs: 3644.11M, Params: 9.50M , time: 0.110430
#     simpnet_58_5_s4  : FLOPs: 1716.95M, Params: 5.91M , time: 0.059609
#     simpnet_58_8_s4  : FLOPs: 2942.52M, Params: 9.50M , time: 0.095201
#  simpnet_58_5_s1_05  : FLOPs: 299.90M, Params: 1.59M , time: 0.022747
#  simpnet_58_8_s1_05  : FLOPs: 528.21M, Params: 2.53M , time: 0.033805
#  simpnet_58_5_s4_05  : FLOPs: 435.58M, Params: 1.59M , time: 0.027759
#  simpnet_58_8_s4_05  : FLOPs: 747.59M, Params: 2.53M , time: 0.041666
#           simpnet5m  : FLOPs: 1174.63M, Params: 5.91M , time: 0.053540
#        simpnet_1.44  : FLOPs: 2414.10M, Params: 11.95M , time: 0.077294
#        simpnet_0.75  : FLOPs: 666.82M, Params: 3.41M , time: 0.029776
#         simpnet_0.5  : FLOPs: 299.90M, Params: 1.59M , time: 0.017542
#     simpnet5m  sz190 : FLOPs: 863.11M, Params: 5.91M , time: 0.033897
#     simpnet5m  sz160 : FLOPs: 863.11M, Params: 5.91M , time: 0.033502
#   simpnet_1.44 sz190 : FLOPs: 1773.79M, Params: 11.95M , time: 0.058026
#   simpnet_1.44 sz160 : FLOPs: 1231.99M, Params: 11.95M , time: 0.050534
#   simpnet_0.75 sz190 : FLOPs: 490.00M, Params: 3.41M , time: 0.029582
#   simpnet_0.75 sz160 : FLOPs: 340.37M, Params: 3.41M , time: 0.022814
#    simpnet_0.5 sz160 : FLOPs: 153.11M, Params: 1.59M , time: 0.013786
#          simpnet_s4  : FLOPs: 1716.95M, Params: 5.91M , time: 0.059109
#     simpnet_s4_1.44  : FLOPs: 3534.48M, Params: 11.95M , time: 0.103706
#     simpnet_s4_0.75  : FLOPs: 971.95M, Params: 3.41M , time: 0.040231
#  simpnet5m_s4  sz190 : FLOPs: 1261.55M, Params: 5.91M , time: 0.044950
#  simpnet5m_s4  sz160 : FLOPs: 1261.55M, Params: 5.91M , time: 0.044913
# simpnet_s4_1.44 sz190 : FLOPs: 2596.92M, Params: 11.95M , time: 0.078140
# simpnet_s4_1.44 sz160 : FLOPs: 1803.61M, Params: 11.95M , time: 0.065804
# simpnet_s4_0.75 sz190 : FLOPs: 714.17M, Params: 3.41M , time: 0.035172
# simpnet_s4_0.75 sz160 : FLOPs: 496.05M, Params: 3.41M , time: 0.027606
# simpnet_s4_0.5 sz160 : FLOPs: 222.34M, Params: 1.59M , time: 0.012082
#          simpnet_s6  : FLOPs: 2975.78M, Params: 5.90M , time: 0.099708
#        simpnet_5m_dw : FLOPs: 636.39M, Params: 3.31M , time: 0.052377
#     simpnet_5m_dw_s7 : FLOPs: 823.42M, Params: 3.23M , time: 0.117840
#        simpnet_1m_s1 : FLOPs: 387.73M, Params: 1.15M , time: 0.024198
#        simpnet_1m_s2 : FLOPs: 1080.06M, Params: 1.15M , time: 0.047627
#        simpnet_1m_s4 : FLOPs: 561.68M, Params: 1.15M , time: 0.029373
#        simpnet_1m_s6 : FLOPs: 1145.05M, Params: 1.15M , time: 0.053492
#      simpnet_300k_s1 : FLOPs: 110.28M, Params: 0.39M , time: 0.009799
#      simpnet_300k_s2 : FLOPs: 307.27M, Params: 0.39M , time: 0.019013
#      simpnet_600k_s1 : FLOPs: 223.01M, Params: 0.72M , time: 0.020514
#      simpnet_600k_s2 : FLOPs: 645.76M, Params: 0.72M , time: 0.030374
#         simpnet8m_s1 : FLOPs: 2065.52M, Params: 9.50M , time: 0.078380
#         simpnet8m_s2 : FLOPs: 6151.18M, Params: 9.50M , time: 0.171757
#         simpnet8m_s4 : FLOPs: 2942.52M, Params: 9.50M , time: 0.092437
#         simpnet8m_s6 : FLOPs: 5793.74M, Params: 9.50M , time: 0.177844


# stats based on batch of 10:
#             resnet18 : FLOPs: 1816.41M, Params: 11.69M , time: 0.634766
#             resnet50 : FLOPs: 4098.89M, Params: 25.56M , time: 1.515249
#              alexnet : FLOPs: 714.69M, Params: 61.10M , time: 0.211404
#                vgg16 : FLOPs: 15483.83M, Params: 138.36M , time: 3.887304
#           squeezenet : FLOPs: 823.44M, Params: 1.25M , time: 0.360630
#            mobilenet : FLOPs: 573.83M, Params: 4.23M , time: 0.531835
#          mobilenetv2 : FLOPs: 320.19M, Params: 3.51M , time: 0.460152
#      mobilenetv2_1.4 : FLOPs: 620.54M, Params: 6.11M , time: 0.715015
#     mobilenetv2_0.75 : FLOPs: 222.00M, Params: 2.64M , time: 0.385636
#      mobilenetv2_192 : FLOPs: 320.19M, Params: 3.51M , time: 0.467648
#      mobilenetv2_160 : FLOPs: 320.19M, Params: 3.51M , time: 0.464727
#           shufflenet : FLOPs: 149.51M, Params: 2.31M , time: 0.200023
#       shufflenet_0.5 : FLOPs: 42.29M, Params: 1.37M , time: 0.098845
#    shufflenet  sz190 : FLOPs: 110.11M, Params: 2.31M , time: 0.157012
# shufflenet_0.5  sz190 : FLOPs: 31.33M, Params: 1.37M , time: 0.078107
#        simplenet_3p  : FLOPs: 3830.96M, Params: 5.75M , time: 1.055566
#     simplenet_3p_v2  : FLOPs: 1840.82M, Params: 5.75M , time: 0.583570
#         simplenetv1  : FLOPs: 1951.44M, Params: 5.75M , time: 0.608631
#     simpnet_58_5_s1  : FLOPs: 1174.63M, Params: 5.91M , time: 0.377779
#     simpnet_58_8_s1  : FLOPs: 2065.52M, Params: 9.50M , time: 0.671913
#     simpnet_58_5_s3  : FLOPs: 2064.07M, Params: 5.91M , time: 0.640364
#     simpnet_58_8_s3  : FLOPs: 3644.11M, Params: 9.50M , time: 1.039464
#     simpnet_58_5_s4  : FLOPs: 1716.95M, Params: 5.91M , time: 0.538528
#     simpnet_58_8_s4  : FLOPs: 2942.52M, Params: 9.50M , time: 0.847926
#  simpnet_58_5_s1_05  : FLOPs: 299.90M, Params: 1.59M , time: 0.125994
#  simpnet_58_8_s1_05  : FLOPs: 528.21M, Params: 2.53M , time: 0.218239
#  simpnet_58_5_s4_05  : FLOPs: 435.58M, Params: 1.59M , time: 0.165458
#  simpnet_58_8_s4_05  : FLOPs: 747.59M, Params: 2.53M , time: 0.280498
#           simpnet5m  : FLOPs: 1174.63M, Params: 5.91M , time: 0.405623
#        simpnet_1.44  : FLOPs: 2414.10M, Params: 11.95M , time: 0.764479
#        simpnet_0.75  : FLOPs: 666.82M, Params: 3.41M , time: 0.232819
#         simpnet_0.5  : FLOPs: 299.90M, Params: 1.59M , time: 0.125307
#     simpnet5m  sz190 : FLOPs: 863.11M, Params: 5.91M , time: 0.275991
#     simpnet5m  sz160 : FLOPs: 863.11M, Params: 5.91M , time: 0.299556
#   simpnet_1.44 sz190 : FLOPs: 1773.79M, Params: 11.95M , time: 0.528207
#   simpnet_1.44 sz160 : FLOPs: 1231.99M, Params: 11.95M , time: 0.376876
#   simpnet_0.75 sz190 : FLOPs: 490.00M, Params: 3.41M , time: 0.178142
#   simpnet_0.75 sz160 : FLOPs: 340.37M, Params: 3.41M , time: 0.119055
#    simpnet_0.5 sz160 : FLOPs: 153.11M, Params: 1.59M , time: 0.067263
#          simpnet_s4  : FLOPs: 1716.95M, Params: 5.91M , time: 0.521521
#     simpnet_s4_1.44  : FLOPs: 3534.48M, Params: 11.95M , time: 0.978482
#     simpnet_s4_0.75  : FLOPs: 971.95M, Params: 3.41M , time: 0.340228
#  simpnet5m_s4  sz190 : FLOPs: 1261.55M, Params: 5.91M , time: 0.383674
#  simpnet5m_s4  sz160 : FLOPs: 1261.55M, Params: 5.91M , time: 0.405564
# simpnet_s4_1.44 sz190 : FLOPs: 2596.92M, Params: 11.95M , time: 0.708107
# simpnet_s4_1.44 sz160 : FLOPs: 1803.61M, Params: 11.95M , time: 0.525470
# simpnet_s4_0.75 sz190 : FLOPs: 714.17M, Params: 3.41M , time: 0.240049
# simpnet_s4_0.75 sz160 : FLOPs: 496.05M, Params: 3.41M , time: 0.166924
# simpnet_s4_0.5 sz160 : FLOPs: 222.34M, Params: 1.59M , time: 0.084386
#          simpnet_s6  : FLOPs: 2975.78M, Params: 5.90M , time: 0.909677
#        simpnet_5m_dw : FLOPs: 636.39M, Params: 3.31M , time: 0.308350
#     simpnet_5m_dw_s7 : FLOPs: 823.42M, Params: 3.23M , time: 0.751869
#        simpnet_1m_s1 : FLOPs: 387.73M, Params: 1.15M , time: 0.196563
#        simpnet_1m_s2 : FLOPs: 1080.06M, Params: 1.15M , time: 0.408943
#        simpnet_1m_s4 : FLOPs: 561.68M, Params: 1.15M , time: 0.255960
#        simpnet_1m_s6 : FLOPs: 1145.05M, Params: 1.15M , time: 0.459294
#      simpnet_300k_s1 : FLOPs: 110.28M, Params: 0.39M , time: 0.075756
#      simpnet_300k_s2 : FLOPs: 307.27M, Params: 0.39M , time: 0.144748
#      simpnet_600k_s1 : FLOPs: 223.01M, Params: 0.72M , time: 0.123702
#      simpnet_600k_s2 : FLOPs: 645.76M, Params: 0.72M , time: 0.273277
#         simpnet8m_s1 : FLOPs: 2065.52M, Params: 9.50M , time: 0.676806
#         simpnet8m_s2 : FLOPs: 6151.18M, Params: 9.50M , time: 1.691572
#         simpnet8m_s4 : FLOPs: 2942.52M, Params: 9.50M , time: 0.870292
#         simpnet8m_s6 : FLOPs: 5793.74M, Params: 9.50M , time: 1.624610


# stats based on batch of 100:
#             resnet18 : FLOPs: 1816.41M, Params: 11.69M , time: 6.383858
#             resnet50 : FLOPs: 4098.89M, Params: 25.56M , time: 15.686216
#              alexnet : FLOPs: 714.69M, Params: 61.10M , time: 2.069043
#                vgg16 : FLOPs: 15483.83M, Params: 138.36M , time: 37.223831
#           squeezenet : FLOPs: 823.44M, Params: 1.25M , time: 3.583417
#            mobilenet : FLOPs: 573.83M, Params: 4.23M , time: 5.144241
#          mobilenetv2 : FLOPs: 320.19M, Params: 3.51M , time: 4.477428
#      mobilenetv2_1.4 : FLOPs: 620.54M, Params: 6.11M , time: 6.671273
#     mobilenetv2_0.75 : FLOPs: 222.00M, Params: 2.64M , time: 3.759182
#      mobilenetv2_192 : FLOPs: 320.19M, Params: 3.51M , time: 4.486594
#      mobilenetv2_160 : FLOPs: 320.19M, Params: 3.51M , time: 4.569482
#           shufflenet : FLOPs: 149.51M, Params: 2.31M , time: 1.732287
#       shufflenet_0.5 : FLOPs: 42.29M, Params: 1.37M , time: 0.894063
#    shufflenet  sz190 : FLOPs: 110.11M, Params: 2.31M , time: 1.376643
# shufflenet_0.5  sz190 : FLOPs: 31.33M, Params: 1.37M , time: 0.687459
#        simplenet_3p  : FLOPs: 3830.96M, Params: 5.75M , time: 10.092173
#     simplenet_3p_v2  : FLOPs: 1840.82M, Params: 5.75M , time: 5.805986
#         simplenetv1  : FLOPs: 1951.44M, Params: 5.75M , time: 6.198499
#     simpnet_58_5_s1  : FLOPs: 1174.63M, Params: 5.91M , time: 3.765929
#     simpnet_58_8_s1  : FLOPs: 2065.52M, Params: 9.50M , time: 6.742744
#     simpnet_58_5_s3  : FLOPs: 2064.07M, Params: 5.91M , time: 6.157910
#     simpnet_58_8_s3  : FLOPs: 3644.11M, Params: 9.50M , time: 10.125538
#     simpnet_58_5_s4  : FLOPs: 1716.95M, Params: 5.91M , time: 5.255367
#     simpnet_58_8_s4  : FLOPs: 2942.52M, Params: 9.50M , time: 8.846459
#  simpnet_58_5_s1_05  : FLOPs: 299.90M, Params: 1.59M , time: 1.495351
#  simpnet_58_8_s1_05  : FLOPs: 528.21M, Params: 2.53M , time: 2.445443
#  simpnet_58_5_s4_05  : FLOPs: 435.58M, Params: 1.59M , time: 1.788296
#  simpnet_58_8_s4_05  : FLOPs: 747.59M, Params: 2.53M , time: 2.767543
#           simpnet5m  : FLOPs: 1174.63M, Params: 5.91M , time: 3.777447
#        simpnet_1.44  : FLOPs: 2414.10M, Params: 11.95M , time: 7.686273
#        simpnet_0.75  : FLOPs: 666.82M, Params: 3.41M , time: 2.417988
#         simpnet_0.5  : FLOPs: 299.90M, Params: 1.59M , time: 1.250004
#     simpnet5m  sz190 : FLOPs: 863.11M, Params: 5.91M , time: 2.662381
#     simpnet5m  sz160 : FLOPs: 863.11M, Params: 5.91M , time: 2.650369
#   simpnet_1.44 sz190 : FLOPs: 1773.79M, Params: 11.95M , time: 5.351413
#   simpnet_1.44 sz160 : FLOPs: 1231.99M, Params: 11.95M , time: 3.579961
#   simpnet_0.75 sz190 : FLOPs: 490.00M, Params: 3.41M , time: 1.703938
#   simpnet_0.75 sz160 : FLOPs: 340.37M, Params: 3.41M , time: 1.244562
#    simpnet_0.5 sz160 : FLOPs: 153.11M, Params: 1.59M , time: 0.613823
#          simpnet_s4  : FLOPs: 1716.95M, Params: 5.91M , time: 5.299309
#     simpnet_s4_1.44  : FLOPs: 3534.48M, Params: 11.95M , time: 9.938613
#     simpnet_s4_0.75  : FLOPs: 971.95M, Params: 3.41M , time: 3.369827
#  simpnet5m_s4  sz190 : FLOPs: 1261.55M, Params: 5.91M , time: 3.856621
#  simpnet5m_s4  sz160 : FLOPs: 1261.55M, Params: 5.91M , time: 3.774517
# simpnet_s4_1.44 sz190 : FLOPs: 2596.92M, Params: 11.95M , time: 7.199849
# simpnet_s4_1.44 sz160 : FLOPs: 1803.61M, Params: 11.95M , time: 5.074567
# simpnet_s4_0.75 sz190 : FLOPs: 714.17M, Params: 3.41M , time: 2.371324
# simpnet_s4_0.75 sz160 : FLOPs: 496.05M, Params: 3.41M , time: 1.675670
# simpnet_s4_0.5 sz160 : FLOPs: 222.34M, Params: 1.59M , time: 0.835029
#          simpnet_s6  : FLOPs: 2975.78M, Params: 5.90M , time: 9.023412
#        simpnet_5m_dw : FLOPs: 636.39M, Params: 3.31M , time: 2.970289
#     simpnet_5m_dw_s7 : FLOPs: 823.42M, Params: 3.23M , time: 8.058406
#        simpnet_1m_s1 : FLOPs: 387.73M, Params: 1.15M , time: 1.850731
#        simpnet_1m_s2 : FLOPs: 1080.06M, Params: 1.15M , time: 4.128092
#        simpnet_1m_s4 : FLOPs: 561.68M, Params: 1.15M , time: 2.535051
#        simpnet_1m_s6 : FLOPs: 1145.05M, Params: 1.15M , time: 4.518381
#      simpnet_300k_s1 : FLOPs: 110.28M, Params: 0.39M , time: 0.687945
#      simpnet_300k_s2 : FLOPs: 307.27M, Params: 0.39M , time: 1.513833
#      simpnet_600k_s1 : FLOPs: 223.01M, Params: 0.72M , time: 1.062197
#      simpnet_600k_s2 : FLOPs: 645.76M, Params: 0.72M , time: 2.648964
#         simpnet8m_s1 : FLOPs: 2065.52M, Params: 9.50M , time: 6.858096
#         simpnet8m_s2 : FLOPs: 6151.18M, Params: 9.50M , time: 16.499931
#         simpnet8m_s4 : FLOPs: 2942.52M, Params: 9.50M , time: 8.907443
#         simpnet8m_s6 : FLOPs: 5793.74M, Params: 9.50M , time: 15.892276