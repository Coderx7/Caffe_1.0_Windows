#!/bin/bash
#In the name of God the most compassionate the most merciful 

# training count for each model
ITERATION=1
LR=0.1
SAVE_DIR=./snapshots/simpnet
DATASET_DIR=./data/cifar.python
WORKER=2

WEIGHT_DECAY=0.001 #0.002

ARCH=simpnet
DATASET=cifar10
EPOCHS=550
BATCH_SIZE=100
WORKER=2
CHECKPOINT=./snapshots/simplenet/chkpt_simplenet_cifar10_
#OUTPUT_DIR=/media/hossein/SSD/svhn

for (( i=1; i <= $ITERATION; i++ ))
do
python main.py  $DATASET_DIR --dataset $DATASET --arch $ARCH --save_path $SAVE_DIR --epochs $EPOCHS --learning_rate $LR --batch_size $BATCH_SIZE \
--decay $WEIGHT_DECAY --workers $WORKER 
done

#Edit the model for cifar100! first
ARCH=simpnet
DATASET=cifar100
EPOCHS=550
BATCH_SIZE=100
WORKER=2
CHECKPOINT=./snapshots/simpnet/chkpt_simplenet_cifar10_
#OUTPUT_DIR=/media/hossein/SSD/svhn

for (( i=1; i <= $ITERATION; i++ ))
do
python main.py  $DATASET_DIR --dataset $DATASET --arch $ARCH --save_path $SAVE_DIR --epochs $EPOCHS --learning_rate $LR --batch_size $BATCH_SIZE \
--decay $WEIGHT_DECAY --workers $WORKER 
done


ARCH=simpnet8m
DATASET=cifar10
EPOCHS=550
BATCH_SIZE=100
WORKER=2
CHECKPOINT=./snapshots/simpnet/chkpt_simplenet_cifar10_
#OUTPUT_DIR=/media/hossein/SSD/svhn

for (( i=1; i <= $ITERATION; i++ ))
do
python main.py  $DATASET_DIR --dataset $DATASET --arch $ARCH --save_path $SAVE_DIR --epochs $EPOCHS --learning_rate $LR --batch_size $BATCH_SIZE \
--decay $WEIGHT_DECAY --workers $WORKER 
done

#edit the model for cifar100 first 
ARCH=simpnet8m
DATASET=cifar100
EPOCHS=550
BATCH_SIZE=100
WORKER=2
CHECKPOINT=./snapshots/simpnet/chkpt_simplenet_cifar10_
#OUTPUT_DIR=/media/hossein/SSD/svhn

for (( i=1; i <= $ITERATION; i++ ))
do
python main.py  $DATASET_DIR --dataset $DATASET --arch $ARCH --save_path $SAVE_DIR --epochs $EPOCHS --learning_rate $LR --batch_size $BATCH_SIZE \
--decay $WEIGHT_DECAY --workers $WORKER 
done

