#in the name of God the most compassionate the most merciful 

ITERATION=3
IMAGENET_DIR=/media/hossein/DataSection/DeepLearning/ImageNet_DataSet
TRAINING_DIR=training_set_t12/
VAL_DIR=imagenet_val/
SAVE_DIR=./snapshots/simpnet/

EPOCHS=100
BATCH_SIZE=128
#increase t he worker for faster training, 16 to 32 can be used based on the system you have 
WORKER=2

#MODEL_NAME=simpnet_imgnet_5m_nodrp_safc_s1
# CUDA_LAUNCH_BLOCKING=1 python imagenet_train.py $IMAGENET_DIR --train_dir_name $TRAINING_DIR --val_dir_name $VAL_DIR \
#  --arch $MODEL_NAME --save_dir $SAVE_DIR -j $WORKER --epochs $EPOCHS --batch-size $BATCH_SIZE

for (( i=1; i <= $ITERATION; i++ ))
do
   echo "$number " $i
done


#5Mil - no drp
MODEL_NAME=simpnet_imgnet_5m_nodrp_safc_s1
for (( i=1; i <= $ITERATION; i++ ))
do
 echo $MODEL_NAME $number
done

MODEL_NAME=simpnet_imgnet_5m_nodrp_safc_s2
for (( i=1; i <= $ITERATION; i++ ))
do
 echo $MODEL_NAME $number
done

MODEL_NAME=simpnet_imgnet_5m_nodrp_safc_s3
for (( i=1; i <= $ITERATION; i++ ))
do
 echo $MODEL_NAME $number
done


#5Mil drpall
MODEL_NAME=simpnet_imgnet_5m_drpall_s1
for (( i=1; i <= $ITERATION; i++ ))
do
 echo $MODEL_NAME $number
done

MODEL_NAME=simpnet_imgnet_5m_drpall_s2
for (( i=1; i <= $ITERATION; i++ ))
do
 echo $MODEL_NAME $number
done

MODEL_NAME=simpnet_imgnet_5m_drpall_s3
for (( i=1; i <= $ITERATION; i++ ))
do
echo $MODEL_NAME $number
done


#8.9Mil - no drp 
MODEL_NAME=simpnet_imgnet_8m_nodrp_safc_s1
for (( i=1; i <= $ITERATION; i++ ))
do
echo $MODEL_NAME $number
done

MODEL_NAME=simpnet_imgnet_8m_nodrp_safc_s2
for (( i=1; i <= $ITERATION; i++ ))
do
echo $MODEL_NAME $number
done

MODEL_NAME=simpnet_imgnet_8m_nodrp_safc_s3
for (( i=1; i <= $ITERATION; i++ ))
do
echo $MODEL_NAME $number
done


#8.9Mil drpall
MODEL_NAME=simpnet_imgnet_8m_drpall_s1
for (( i=1; i <= $ITERATION; i++ ))
do
echo $MODEL_NAME $number
done

MODEL_NAME=simpnet_imgnet_8m_drpall_s2
for (( i=1; i <= $ITERATION; i++ ))
do
echo $MODEL_NAME $number
done


MODEL_NAME=simpnet_imgnet_8m_drpall_s3
for (( i=1; i <= $ITERATION; i++ ))
do
echo $MODEL_NAME $number
done



#5M SimpleNetV1
MODEL_NAME=simplenet_imagenet
for (( i=1; i <= $ITERATION; i++ ))
do
echo $MODEL_NAME $number
done

MODEL_NAME=simplenetv1_imagenet_3p
for (( i=1; i <= $ITERATION; i++ ))
do
echo $MODEL_NAME $number
done

MODEL_NAME=simplenet_imagenet_safc
for (( i=1; i <= $ITERATION; i++ ))
do
echo $MODEL_NAME $number
done